#!/usr/bin/env python3
"""Lecture source -> audited JSON -> MAPL-style workbook PDF. Pure local build (no AI API)."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SCHEMA=ROOT/'schemas/content.schema.json'


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def inspect_content(path,complete=False):
    import jsonschema
    from tools.validate_content import validate
    content=load_json(path)
    schema=load_json(SCHEMA)
    structural=sorted(jsonschema.Draft202012Validator(schema).iter_errors(content),key=lambda e: str(e.path))
    result=validate(content,complete=complete)
    for err in structural:
        where='.'.join(map(str,err.absolute_path)) or '(root)'
        result['errors'].append({'code':'schema','message':f'{where}: {err.message}'})
    # Page-1 worked question is a required visual structure: don't silently render an empty prompt.
    for i,theme in enumerate(content.get('themes',[]),1):
        cards=theme.get('concept_cards') or []
        if not cards: continue
        worked=cards[0].get('worked') or {}
        if not (worked.get('exercise_questions') or []):
            result['errors'].append({'code':'missing_concept_question','message':f'themes[{i}].concept_cards[0].worked.exercise_questions required; put the actual question above MAPL CORE'})
        if not (worked.get('lines') or []):
            result['errors'].append({'code':'missing_worked_solution','message':f'themes[{i}].concept_cards[0].worked.lines required for 개념익힘풀이'})
        for j,card in enumerate(cards,1):
            if card.get('worked') and card['worked'].get('lines') and not card['worked'].get('exercise_questions'):
                result['warnings'].append({'code':'concept_card_no_example','message':f'themes[{i}] card[{j}] has worked.lines but no worked.exercise_questions'})
    # Prevent internal audit identifiers or automatic continuation tags from
    # leaking into a student-facing manuscript. The audit/editorial metadata is
    # intentionally excluded: it remains available to the content reviewer.
    import re
    def student_strings(node,path='themes'):
        if isinstance(node,str):
            yield path,node
        elif isinstance(node,list):
            for i,item in enumerate(node):
                yield from student_strings(item,f'{path}[{i}]')
        elif isinstance(node,dict):
            for key,item in node.items():
                if key in ('trigger_reason','source_pages','pages'):continue
                yield from student_strings(item,f'{path}.{key}')
    student_view=[('themes',content.get('themes',[])),('meta.visible', {k:v for k,v in content.get('meta',{}).items() if k in ('title','cover_title','short_chapter','chapter_code','cover','subject')})]
    for family,values in student_view:
        for field,s_value in student_strings(values,family):
            if re.search(r'\b[FD]\d{2,4}(?=\s*[·.:-]|\s|$)|\[\s*원본\s*:?\s*(?:p\.?\s*)?\d|\(계속\)',s_value):
                result['errors'].append({'code':'internal_student_label',
                                         'message':f'{field}: 내부 식별자/출처 태그/계속 표시는 학생용 원고에 사용할 수 없음'})
    for j,theme in enumerate(content.get('themes',[]),1):
        special=theme.get('special_lecture')
        if isinstance(special,dict) and special.get('enabled') is not False:
            if not special.get('proof_questions'):
                result['errors'].append({'code':'empty_proof_lecture','message':f'themes[{j}]: 마플특강에는 증명 연습 문항이 필요합니다'})
            if special.get('sections'):
                result['errors'].append({'code':'special_extra_sections','message':f'themes[{j}]: 마플특강은 증명 연습/여백/해설 세 요소만 출력합니다. sections는 비워 주세요'})
    result['status']='PASS' if not result['errors'] else 'FAIL'
    return content,result


def write_report(report,path):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')


def command_extract(args):
    source=Path(args.lecture)
    if not source.is_file(): raise FileNotFoundError(source)
    result={'source_file':source.name,'pages':[],'format':source.suffix.lower()}
    if source.suffix.lower()=='.pdf':
        import fitz
        from PIL import Image
        with fitz.open(source) as pdf:
            result['source_total_pages']=len(pdf)
            preview_dir=Path(args.preview_dir) if args.preview_dir else None
            if preview_dir:preview_dir.mkdir(parents=True,exist_ok=True)
            for i,page in enumerate(pdf,1):
                text=page.get_text('text',sort=True).strip()
                result['pages'].append({'page':i,'text':text,'requires_visual_review':len(text)<30,'size_pt':[round(page.rect.width,1),round(page.rect.height,1)],'image_count':len(page.get_images())})
                if preview_dir:
                    pix=page.get_pixmap(matrix=fitz.Matrix(1.25,1.25),alpha=False)
                    pix.save(preview_dir/f'lecture_page_{i:03d}.png')
    elif source.suffix.lower() in ('.txt','.md'):
        text=source.read_text(encoding='utf-8-sig')
        result['source_total_pages']=1
        result['pages']=[{'page':1,'text':text,'requires_visual_review':False,'size_pt':None,'image_count':0}]
    else:
        raise ValueError('강의노트 입력은 PDF, TXT, MD 지원. PPTX/DOCX는 PDF로 변환 후 사용하세요.')
    output=Path(args.out)
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    skipped=[p['page'] for p in result['pages'] if p['requires_visual_review']]
    print(f'추출 완료: {output} / {len(result["pages"])}페이지')
    if skipped: print(f'주의: 글자 추출이 적은 페이지 {skipped} — AI가 원본 이미지를 직접 읽고 도형·표·공식을 확인해야 함')


def command_checkpoint(args):
    """Record completed AI-authored intervals; never create more than one by itself.

    The AI still researches and authors the source. This command stores a
    verifiable restart point AFTER the segment JSON and PDF are checked.
    """
    import hashlib
    plan=load_json(args.plan)
    segments=plan.get('segments') or []
    if plan.get('full_source_reviewed') is not True:
        raise ValueError('Must complete full lecture source review BEFORE segment production (full_source_reviewed=true in plan).')
    if not segments or not all(isinstance(s,dict) and s.get('themes') for s in segments):
        raise ValueError('Plan requires non-empty segments[] with source-derived theme titles, created before drafting.')
    state_path=Path(args.state)
    state=load_json(state_path) if state_path.exists() else {'plan_file':str(Path(args.plan).resolve()),'next_segment':1,'completed':[]}
    next_i=state.get('next_segment',1)
    if args.status:
        print(json.dumps({'next_segment':next_i,'total_segments':len(segments),'completed':state.get('completed',[]),'instruction':('전체 완료' if next_i>len(segments) else f'다음은 {next_i}번 구간만 제작하세요.')},ensure_ascii=False,indent=2))
        return
    if next_i>len(segments):raise ValueError('All planned segments are completed. No new segment is pending.')
    if args.index is not None and args.index!=next_i:raise ValueError(f'Out-of-order segment: expected {next_i}, got {args.index}.')
    if not args.content or not args.pdf:
        raise ValueError('Commit needs --content segment_NN.json and --pdf built_segment_NN.pdf (strict QA required).')
    content_path=Path(args.content);pdf_path=Path(args.pdf)
    content,report=inspect_content(content_path,complete=False)
    if report['errors']:raise ValueError('Segment JSON validation failed; fix before checkpoint: '+str(report['errors'][:3]))
    planned_titles=segments[next_i-1]['themes']
    actual_titles=[theme['title'] for theme in content.get('themes',[])]
    if actual_titles!=planned_titles:
        raise ValueError(f'Segment {next_i} titles mismatch. Expected {planned_titles}, actual {actual_titles}.')
    planned_pages=segments[next_i-1].get('source_pages')
    actual_pages=sorted({p for theme in content.get('themes',[]) for p in theme.get('source_pages',[])})
    if planned_pages is not None and sorted(planned_pages)!=actual_pages:
        raise ValueError(f'Segment {next_i}: source pages do not match audited plan ({planned_pages} vs {actual_pages}).')
    if not pdf_path.is_file():raise FileNotFoundError(pdf_path)
    qa_file=pdf_path.with_suffix('.qa.json')
    if not qa_file.is_file():raise ValueError(f'QA report missing: {qa_file}')
    qa=load_json(qa_file)
    if qa.get('errors') or qa.get('questions')!=report['questions']:
        raise ValueError('PDF QA has errors or question count differs; checkpoint refused.')
    content_bytes=content_path.read_bytes()
    entry={'segment':next_i,'themes':actual_titles,'content':str(content_path.resolve()),'pdf':str(pdf_path.resolve()),'sha256':hashlib.sha256(content_bytes).hexdigest(),'pages':qa.get('pages'),'questions':qa.get('questions')}
    state['completed'].append(entry)
    state['next_segment']=next_i+1
    state_path.parent.mkdir(parents=True,exist_ok=True)
    write_report(state,state_path)
    print(f'구간 {next_i}/{len(segments)} 검증·저장 완료: {state_path}')
    print('이번에는 여기까지 제작했습니다.' if next_i<len(segments) else '전체 계획 구간 제작을 완료했습니다.')

def command_validate(args):
    _,report=inspect_content(args.content,complete=args.complete)
    report_path=Path(args.report) if args.report else Path(args.content).with_suffix('.validation.json')
    write_report(report,report_path)
    print(f'{report["status"]}: {report["themes"]} themes / {report["questions"]} problems / {len(report["errors"])} errors, {len(report["warnings"])} warnings')
    for err in report['errors'][:15]:print('ERROR:',err.get('message',err))
    print('검증 보고서:',report_path)
    if report['errors']:raise SystemExit(2)


def command_build(args):
    _,report=inspect_content(args.content,complete=args.complete)
    if report['errors']:
        print('검증 실패. PDF 생성을 중단합니다.',file=sys.stderr)
        for err in report['errors'][:20]:print('ERROR:',err.get('message',err),file=sys.stderr)
        raise SystemExit(2)
    from engine.mapl_layout import MaplEngine
    content=load_json(args.content)
    output=Path(args.out) if args.out else Path(args.content).with_suffix('.pdf')
    output.parent.mkdir(parents=True,exist_ok=True)
    result=MaplEngine(content,output,strict=True,pretendard_zip=args.font_zip,font_dir=args.font_dir).make()
    print(f'PDF 생성 완료: {output} / {result["pages"]}페이지, {result["questions"]}문항')
    print('레이아웃 검증:',output.with_suffix('.qa.json'))
    if args.preview_dir:
        preview_pdf(output,Path(args.preview_dir),dpi=args.dpi)


def preview_pdf(pdf_path,out_dir,dpi=160):
    import fitz
    from PIL import Image,ImageOps,ImageDraw
    out_dir.mkdir(parents=True,exist_ok=True)
    sheets=[]
    with fitz.open(pdf_path) as pdf:
        for page_no,page in enumerate(pdf,1):
            pix=page.get_pixmap(matrix=fitz.Matrix(dpi/72,dpi/72),alpha=False)
            png=out_dir/f'page_{page_no:03d}.png'
            pix.save(png)
            with Image.open(png) as image:
                thumb=image.convert('RGB').copy()
            thumb.thumbnail((310,435))
            tile=Image.new('RGB',(328,467),'white')
            tile.paste(thumb,((328-thumb.width)//2,10))
            ImageDraw.Draw(tile).text((12,447),f'Page {page_no}',fill='black')
            sheets.append(tile)
    if sheets:
        cols=min(3,len(sheets));rows=(len(sheets)+cols-1)//cols
        sheet=Image.new('RGB',(cols*328,rows*467),'#e9edf0')
        for i,tile in enumerate(sheets):sheet.paste(tile,((i%cols)*328,(i//cols)*467))
        sheet.save(out_dir/'contact_sheet.png')
    print(f'PNG 검수자료 {len(sheets)}페이지: {out_dir} (contact_sheet.png 포함)')


def command_preview(args):
    preview_pdf(Path(args.pdf),Path(args.out_dir),dpi=args.dpi)


def main():
    parser=argparse.ArgumentParser(description='강의노트 → AI가 만든 JSON → MAPL 레이아웃 PDF 조판 도구')
    sub=parser.add_subparsers(dest='action',required=True)
    ex=sub.add_parser('extract',help='강의 PDF를 페이지별 텍스트·검토 이미지로 추출')
    ex.add_argument('lecture');ex.add_argument('--out',default='output/source_pages.json');ex.add_argument('--preview-dir',default='output/lecture_pages')
    ex.set_defaults(func=command_extract)
    va=sub.add_parser('validate',help='JSON 스키마 및 문항 데이터 검증')
    va.add_argument('content');va.add_argument('--complete',action='store_true',help='원본 전체 커버리지 + 테마 계획 검사')
    va.add_argument('--report');va.set_defaults(func=command_validate)
    bu=sub.add_parser('build',help='PDF 출력 + 자동 레이아웃 오류 검증')
    bu.add_argument('content');bu.add_argument('--out');bu.add_argument('--complete',action='store_true')
    bu.add_argument('--font-zip',help='사용자가 제공한 Pretendard 폰트 ZIP 경로')
    bu.add_argument('--font-dir',help='사용자가 제공한 Pretendard TTF 4종이 들어 있는 폴더')
    bu.add_argument('--preview-dir',default='output/preview');bu.add_argument('--dpi',type=int,default=160)
    bu.set_defaults(func=command_build)
    ck=sub.add_parser('checkpoint',help='전체 강의 분석 뒤 구간별 제작/QA 완료 상태 저장 및 재개')
    ck.add_argument('--plan',required=True,help='전체 강의를 분석하여 AI가 먼저 완성한 plan.json')
    ck.add_argument('--state',default='output/progress.json')
    ck.add_argument('--content',help='현재 구간에서 작성된 JSON')
    ck.add_argument('--pdf',help='해당 JSON으로 검수 완료한 PDF')
    ck.add_argument('--index',type=int,help='확인용 구간 번호 (1-based)')
    ck.add_argument('--status',action='store_true',help='다음에 제작할 구간 조회')
    ck.set_defaults(func=command_checkpoint)
    pr=sub.add_parser('preview',help='기존 PDF를 모든 페이지 PNG로 렌더링')
    pr.add_argument('pdf');pr.add_argument('--out-dir',default='output/preview');pr.add_argument('--dpi',type=int,default=160)
    pr.set_defaults(func=command_preview)
    args=parser.parse_args()
    try:args.func(args)
    except (ValueError,FileNotFoundError,KeyError,RuntimeError) as exc:
        print(f'실행 오류: {exc}',file=sys.stderr)
        raise SystemExit(2)


if __name__=='__main__':main()
