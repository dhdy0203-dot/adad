#!/usr/bin/env python3
"""Editorial preflight for strict-layout workbook JSON; hard errors exit non-zero.
This does not replace human verification of mathematical reasoning or source fidelity.
"""
import argparse,ast,json,math,re
from pathlib import Path

# Rich fields accept string prose, inline LaTeX, or {"latex":"..."} objects.
def value_text(value):
 if isinstance(value,dict):return value.get("latex",value.get("text",""))
 return str(value)

def valid_rich(value):
 return isinstance(value,str) or (isinstance(value,dict) and (isinstance(value.get("latex"),str) and bool(value["latex"].strip()) or isinstance(value.get("text"),str)))

class SafeArithmetic(ast.NodeVisitor):
 def visit_Expression(self,node):return self.visit(node.body)
 def visit_Constant(self,node):
  if type(node.value) not in (int,float):raise ValueError('numeric constants only')
  return float(node.value)
 def visit_UnaryOp(self,node):
  if isinstance(node.op,ast.UAdd):return self.visit(node.operand)
  if isinstance(node.op,ast.USub):return -self.visit(node.operand)
  raise ValueError('unsupported unary operator')
 def visit_BinOp(self,node):
  l,r=self.visit(node.left),self.visit(node.right)
  if isinstance(node.op,ast.Add):return l+r
  if isinstance(node.op,ast.Sub):return l-r
  if isinstance(node.op,ast.Mult):return l*r
  if isinstance(node.op,ast.Div):return l/r
  if isinstance(node.op,ast.Pow):
   if abs(r)>10:raise ValueError('unbounded exponent')
   return l**r
  raise ValueError('unsupported binary operator')
 def generic_visit(self,node):raise ValueError(f'not permitted: {type(node).__name__}')
def calc(expression):return SafeArithmetic().visit(ast.parse(expression,mode='eval'))

def validate(doc,complete=False):
 errs=[]; warns=[]
 def error(code,msg):errs.append({'code':code,'message':msg})
 def warn(code,msg):warns.append({'code':code,'message':msg})
 meta=doc.get('meta',{});themes=doc.get('themes',[])
 if not meta.get('title') or not meta.get('source_title'):error('meta','meta.title and source_title are required')
 if not themes:error('themes','at least one theme is required')
 seen_questions={};seen_pages={};nq=0
 for i,t in enumerate(themes,1):
  path=f'themes[{i}]'
  if not t.get('title'):error('title',f'{path}: missing title')
  if not t.get('pages'):error('source',f'{path}: source page mapping required')
  spp=t.get('source_pages',[])
  if not spp:warn('pages',f'{path}: source_pages numerical list missing')
  for page in spp:
   seen_pages[page]=seen_pages.get(page,0)+1
  cards=t.get('concept_cards',[])
  if not cards:error('cards',f'{path}: at least one concept card required')
  for j,c in enumerate(cards,1):
   if len(c.get('sections',[]))<1:error('sections',f'{path} card{j}: at least one named subsection')
   num=sum(len(sec.get('bullets',[])) for sec in c.get('sections',[]))
   if num<5:warn('underfill',f'{path} card{j}: only {num} bullets; likely visibly sparse')
   for sec in c.get('sections',[]):
    if not sec.get('name') or not sec.get('bullets'):error('bullet',f'{path} card{j}: blank heading or bullets')
  if not t.get('notes',[]):warn('notes',f'{path}: source-derived explanatory notes are recommended')
  special=t.get('special_lecture')
  if special and special.get('enabled',True) and special.get('sections'):
   if len(str(special.get('trigger_reason','')).strip())<12:error('special_reason',f'{path}: special lecture requires source-grounded trigger_reason')
   if not str(special.get('title','')).strip():error('special_title',f'{path}: special lecture requires title')
   for k,proof in enumerate(special.get('proof_questions') or [],1):
    if not isinstance(proof,dict):
     error('special_proof',f'{path}/special_lecture.proof_questions[{k}]: expected object');continue
    for key in ('s','a','e'):
     if not valid_rich(proof.get(key)) or not value_text(proof[key]).strip():
      error('special_proof',f'{path}/special_lecture.proof_questions[{k}]: missing/invalid {key}')
  covered_advanced=[]
  for group in t.get('advanced_types',[]):
   covered_advanced.extend(group.get('question_indices',[]))
   if any(not isinstance(idx,int) or idx<0 or idx>=len(t.get('advanced',[])) for idx in group.get('question_indices',[])):
    error('advanced_type_indices',f'{path}: invalid advanced_types.question_indices')
  if len(covered_advanced)!=len(set(covered_advanced)):
   error('advanced_type_duplicate',f'{path}: advanced question index cannot occur in multiple types')
  if not t.get('formula'):warn('formula',f'{path}: no formula summary')
  # No minimum or fixed question count: page slots (5+5 or 4+4) are pagination capacities, NOT editorial quotas.
  # Do not pad unused slots with artificial variants just to meet a target.
  if not t.get('basic',[]):warn('basic_absent',f'{path}: no basic practice; review whether this theme should be merged')
  if not t.get('advanced',[]):warn('applied_absent',f'{path}: no applied problems; review learning objectives and topic boundaries')
  # v4.3 editorial protocol:
  # - basic(마플개념익힘) = exactly 확인/변형/발전 1개씩
  # - advanced(유형문제) may include 서술형, but proof/discussion belongs in special_lecture
  typed=[q.get('category','확인문제') for q in t.get('basic',[])]
  deviations={category:typed.count(category) for category in ('확인문제','변형문제','발전문제') if typed.count(category)!=1}
  disallowed_basic=[cat for cat in typed if cat not in ('확인문제','변형문제','발전문제')]
  if deviations or len(typed)!=3 or disallowed_basic:
   warn('three_practice_types',f'{path}: 마플개념익힘은 확인/변형/발전 각 1개씩 총 3개가 원칙이며, 증명/논술은 특강으로 분리한다. 현재 {typed}. 레거시 JSON 호환을 위해 경고로 처리')
  if len(typed)>=4 and typed.count('확인문제')/len(typed)>.75:
   warn('concept_practice_imbalance',f'{path}: over 75% of basic problems are direct checks; review variation diversity')
  advanced_cats=[q.get('category','') for q in t.get('advanced',[])]
  if any(cat in ('증명문제','논술형','서술·논술형') for cat in advanced_cats):
   warn('advanced_proof_policy',f'{path}: 유형문제에는 서술형은 둘 수 있으나 증명/논술형은 마플특강으로 분리하는 것이 원칙')
  for fam in ('basic','advanced'):
   for j,q in enumerate(t.get(fam,[]),1):
    if q.get('category') in ('증명문제','서술·논술형','서술형','논술형') and len(value_text(q.get('e',''))) < 35:
     warn('short_written_solution',f'{path}/{fam}[{j}]: proof/essay explanation may need intermediate reasoning and assumptions')
  for c in cards:
   for sec in c.get('sections',[]):
    for b in sec.get('bullets',[]):
     if not valid_rich(b):error('rich_content',f'{path}: invalid concept bullet: {b!r}')
  for mathline in t.get('formula',[]):
   if not valid_rich(mathline):error('formula',f'{path}: formula must be a string or LaTeX object')
  for family in ('basic','advanced'):
   for j,q in enumerate(t.get(family,[]),1):
    label=f'{path}/{family}[{j}]';nq+=1
    for k in ('s','a','e'):
     if not valid_rich(q.get(k)) or not value_text(q[k]).strip():error('question_data',f'{label}: missing/invalid {k}')
    s=re.sub(r'\s+','',value_text(q.get('s','')))
    if s in seen_questions:warn('duplicate',f'{label} duplicates {seen_questions[s]}')
    seen_questions[s]=label
    opts=q.get('ch') or []
    if opts and (len(opts)<2 or len(opts)>5):error('choices',f'{label}: choices must be 2–5')
    for choice in opts:
     if not valid_rich(choice):error('choices_rich',f'{label}: invalid LaTeX/choice format')
    if opts and value_text(q.get('a','')).strip() in '①②③④⑤' and '①②③④⑤'.index(value_text(q['a']).strip())>=len(opts):error('answer_outside_choices',label)
    ck=q.get('numeric_check')
    if ck:
     try:
      actual=calc(ck['expression']);expected=float(ck['expected']);tolerance=float(ck.get('tolerance',1e-7))
      if abs(actual-expected)>tolerance:error('calculation',f'{label}: {ck["expression"]} = {actual}, claimed {expected}')
     except (ValueError,TypeError,KeyError,ZeroDivisionError,OverflowError,SyntaxError) as e:error('numeric_check',f'{label}: {e}')
 # For complete production, require an auditable analysis CREATED BEFORE problem generation.
 if complete:
  editorial=doc.get('editorial',{})
  plan=editorial.get('theme_plan',[])
  if not editorial.get('source_inventory_reviewed'):
   error('source_inventory','editorial.source_inventory_reviewed must be true after full source audit')
  if len(editorial.get('theme_count_reason','').strip())<30:
   error('theme_count_reason','Explain the whole-source theme split/merge choice (not a fixed default count).')
  if len(plan)!=len(themes):
   error('theme_plan','theme_plan must have one individually justified entry per theme before authoring')
  else:
   for i,(planned,t) in enumerate(zip(plan,themes),1):
    label=f'editorial.theme_plan[{i}]'
    if planned.get('theme_title')!=t.get('title'):
     error('theme_plan_mapping',f'{label}: plan title does not match actual theme')
    if sorted(planned.get('source_pages',[]))!=sorted(t.get('source_pages',[])):
     error('theme_plan_pages',f'{label}: source pages must match theme coverage')
    for key in ('split_merge_reason','difficulty_reason','allocation_reason'):
     if len(planned.get(key,'').strip())<20:
      error('theme_plan_reason',f'{label}: meaningful {key} needed')
    if len(planned.get('required_skills',[]))<2:
     error('skills',f'{label}: at least two distinct source-derived tested skills')
    for kind,field in [('basic','planned_basic'),('advanced','planned_advanced')]:
     if planned.get(field)!=len(t.get(kind,[])):
      error('allocation_mismatch',f'{label}: {field} differs from authored {kind} items')
 if complete:
  total=int(meta.get('source_total_pages',0))
  if total<1:error('source_total_pages','required for --complete')
  else:
   excluded={it.get('page') for it in doc.get('audit',{}).get('exclusions',[]) if isinstance(it,dict) and len(it.get('reason','').strip())>4}
   excluded.update(doc.get('editorial',{}).get('excluded_source_pages',[]))
   missing=[i for i in range(1,total+1) if i not in seen_pages and i not in excluded]
   if missing:error('missing_source_pages',str(missing))
  if not doc.get('audit',{}).get('coverage_reviewed'):error('coverage_review','audit.coverage_reviewed must be true after page-by-page human checking')
 return dict(status='PASS' if not errs else 'FAIL',themes=len(themes),questions=nq,source_pages_mentioned=sorted(seen_pages),errors=errs,warnings=warns)

def main():
 p=argparse.ArgumentParser();p.add_argument('--content',required=True);p.add_argument('--complete',action='store_true');p.add_argument('--report');args=p.parse_args()
 results=validate(json.loads(Path(args.content).read_text(encoding='utf-8')),args.complete)
 print(json.dumps(results,ensure_ascii=False,indent=2))
 if args.report:Path(args.report).write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 raise SystemExit(0 if results['status']=='PASS' else 2)
if __name__=='__main__':main()
