# AI 작업 흐름 지침 — 강의노트 → JSON → 문제집 PDF

> **이 파일의 범위는 데이터 작성·검증·조판·배포 절차에 한정된다.** 개념을 어떻게 설명하고 어떤 문제를 만들지는 별도 독립 파일 **[`개념설명_문제출제_지침.md`](개념설명_문제출제_지침.md)** 를 반드시 먼저 읽고 따른다.
>
> 프로젝트는 AI 모델을 내장하지 않는다. 교육적 판단과 수학적 검산은 원고를 작성하는 AI 또는 편집자가 수행하고, Python 엔진은 JSON 검증·PDF 조판·진행 상태 관리에 사용된다. `samples/미니샘플.json`의 수치·분량·문항 수를 새 강의에 복사하지 않는다.

## 최우선 출판 지침: 학생용 표기·마플특강

- 학생용 모든 출력에서 내부 검사 ID(`F009`, `D03` 등), 원본 페이지 표기(`[원본:2]`, `[원본 p.2]` 등), `(계속)` 표시를 **금지**한다. 대응 코드와 원본 페이지는 `audit`/별도 검수표에만 기록한다.
- 강의노트의 수학적 용어·기호·전제를 우선한다. 없는 전문용어를 일방적으로 집어넣지 않는다.
- 마플특강은 **증명 연습 문제(`proof_questions[].s`) → 최소 225pt 이상의 필기 여백 → 증명 해설(`proof_questions[].e`)**의 3단만 출력한다. `proof_questions[].a`는 내부 채점용으로 보관할 수 있으나 독립 정답 칸으로 출력 금지. `special_lecture.sections[]=[]`로 두며 그 내용은 학생에게 출력하지 않는다.
- 원본의 실제 모든 증명/유도는 별도의 증명 문제로 빠짐없이 구성하고, 그 문제와 풀이를 내부 원본 대조표로 연결한다. 모든 공식의 개념 본문 수록 및 유형당 최소 3문항 규칙도 계속 적용한다.
- PDF 조판 결과에 금지된 학생용 태그가 보이거나, 여백 없이 증명 해설이 붙으면 **검증 실패**로 처리한다.

## 1. 입력 자료와 원본 페이지 조사

1. 강의노트 전체 페이지 수를 확인한다. PDF 입력 시 가능한 환경에서 다음 명령으로 페이지별 텍스트와 PNG를 추출한다.

```bash
python run.py extract lecture.pdf --out output/source_pages.json
```

2. 추출 텍스트 외에 스캔 이미지, 도형, 그래프, 주석을 직접 확인한다. 제외/미확인 페이지가 있다면 페이지 번호와 이유를 기록한다.
3. **전체 원본을 읽고 먼저 편집 계획을 완성**한다. 계획의 교육적 기준은 `개념설명_문제출제_지침.md`를 따른다. **과목을 불문하고 실제 전개된 모든 논증·유도·증명은 마플특강 전수 반영 대상으로, 모든 공식·정리·관계식(원문에 증명이 없는 항목 포함)은 개념다지기 전수 반영 대상으로** 항목별로 등록한다. 각 유형의 실전문제도 **최소 3문항 이상** 계획한다. 테마 수와 문항 수를 샘플에 맞춰 임의로 고정하지 않는다.
4. 전체 계획을 `output/production_plan.json`에 기록한다. 구조 예시는 `samples/production_plan_example.json`에 있다. `full_source_reviewed: true`는 실제로 전체를 대조했을 때만 입력한다.

## 2. JSON 원고 구조·필드 매핑

`schemas/content.schema.json`을 규격으로 사용하고 `samples/상세예시_함수의극한.json`, `samples/미니샘플.json`을 **필드 예제**로만 참조한다.

| 부위 | 주요 입력 필드 |
|---|---|
| 표지·출처 | `meta.title`, `meta.source_title`, `meta.source_total_pages`, `meta.short_chapter`, `meta.page_number_start`, `meta.reference_mascot_preview`, 선택적 `meta.cover` |
| 원본 대응 | `themes[].source_pages`(실제 페이지 번호), `themes[].pages`(읽기 쉬운 표시, 예: `3-7`) |
| 개념다지기 | `concept_cards[].sections[].name`, `sections[].bullets[]`, 필요 시 `figure`, `notes` |
| 개념 직후 대표 예시 | `concept_cards[].worked.exercise_questions[]` + 정답·풀이 `worked.lines[]` |
| 핵심 힌트 | `mapl_core` |
| 개념익힘 | `themes[].basic[]`의 `category`, `s`, `a`, `e` 및 객관식일 때 `ch` |
| 유형문제 (유형당 최소 3문항) | `themes[].advanced[]` 및 `advanced_types[]`의 `title`, `intro`, `key_points`, `question_indices`(유형별 서로 다른 유효 인덱스 3개 이상) |
| 원본 논증·유도 전수 반영 | 원본에 실제 전개된 항목이 있으면 `special_lecture`의 `title`, `trigger_reason`, `proof_questions[]` (마플특강 `sections[]`는 빈 배열)에 **항목별로 누락 없이** 반영 |
| 원본의 공식·정리·관계식 전체 (증명 없는 결과식 포함) | **`concept_cards[].sections[]` 본문에 필수 수록**, 필요한 경우 `formula[]`에 재수록 (`formula[]`만으로 대체 불가) |
| 원본 추적 | `editorial.theme_plan`, `audit.source_checklist`, `audit.added_material`, `audit.coverage_reviewed` 등 |

- 각 문제의 기본 필드 `s`(문제), `a`(정답), `e`(풀이)를 유지한다. 선택 사항인 `category`, `answer_format`, `rubric`, `source_basis`, `added_by_ai`는 기본 필드를 대체하지 않는다.
- `advanced_types[].question_indices`는 해당 테마 `advanced` 배열의 **0부터 시작하는 인덱스**다. **각 유형에 실제 존재하는 서로 다른 문항을 최소 3개씩 연결**한다. 동일 인덱스 반복·같은 문항 복제·유형 간 중복 문항 재사용은 3개로 세지 않으며, 인덱스가 맞아도 문항의 `s`·`a`·`e`가 빈약하면 미완료로 본다.
- `worked.exercise_questions[]`와 `worked.lines[]`는 항목별로 대응시킨다. 예제 문제를 비워 둔 채 풀이만 쓰지 않는다.
- `figure` 프리셋은 `number_line`, `coordinate_plane`, `plot`, `triangle`이다. 도형 이름만 써서 복잡한 그림을 자동으로 만든다고 가정하지 않는다.
- 원본에 실제 전개된 논증·유도·증명이 **있다면 `special_lecture`는 필수**다. 해당하는 원본 항목이 없는 경우에만, 다른 심화 필요성도 없으면 빈 틀을 남기지 않고 키를 생략한다. `special_lecture`가 있다고 해도 **각 원본 항목의 설명·문항·해설이 실제 있는지** 별도 확인한다.
- **원본에서 증명 없이 제시된 공식·정리·정의식·관계식도 모두 개념다지기에 필수 반영**한다. 공식집 `formula[]`, 특강, 예제, 해설에만 등장하면 미반영으로 판정한다. 원본에 도출이 없는 내용을 '원본 증명'으로 꾸미지 않는다.
- 실제 문제 수, 개념 설명 수준, 특강의 배치·출제 기준은 **독립 집필 지침**에 있다. 이 파일에서 중복 규정하지 않는다.

## 3. 수식·JSON 입력 규칙

- 수식은 `\( ... \)`, `\[ ... \]`, `$$ ... $$` 또는 `{"latex": "...", "display": true}` 형태로 표시한다.
- JSON 파일에서 실제 TeX 역슬래시는 `\\`로 이스케이프한다. 문장 안에 원시 `\frac`·`\lambda`·`\qquad` 등을 감싸지 않고 넣지 않는다.
- 식은 의미 있는 단위로 나누고 기호의 정의·조건·첨자를 빠뜨리지 않는다.
- `s`, `a`, `e`, `ch`, `formula` 모두 동일한 규칙을 적용한다.
- 인라인 수식과 한글 사이 여백은 엔진이 정규화한다. 중복 공백을 강제로 덧붙이지 않는다.
- 그래프와 도형의 실제 좌표·조건이 원고 내용과 일치하는지는 집필 단계에서 확인하고, 렌더링 결과는 별도로 시각 검수한다.

## 4. 전체 선분석 → 구간별 제작 → 체크포인트

1. 먼저 전체 강의의 테마·원본 페이지 대응과 제작 구간 경계를 확정한다. 분량이 많으면 테마의 완결성과 검수 가능성을 기준으로 여러 구간으로 나눈다.
2. **첫 구간만** 집필 지침에 따라 완성하고 JSON을 작성한다. 이때 해당 구간의 **원본 논증·유도 전수 목록과 마플특강의 일대일 대조, 원본 공식 전수 목록과 개념다지기의 일대일 대조, 유형별 3문항 이상 배정 검수**를 완료한다. 다음 명령으로 검증, PDF 생성, 진행 상태를 기록한다.

```bash
python run.py validate output/segment_01.json
python run.py build output/segment_01.json --out output/segment_01.pdf --font-zip /path/to/Pretendard.zip
python run.py checkpoint --plan output/production_plan.json --state output/progress.json --content output/segment_01.json --pdf output/segment_01.pdf
```

3. JSON 검증과 PDF 시각 검수를 끝낸 뒤 **완료 구간과 다음 구간**을 명시하고 멈춘다. 여러 구간을 한 번에 억지로 제작하지 않는다.
4. 사용자가 이어 쓰기를 요청할 때 상태를 조회한다. 완료된 파일을 함부로 덮어쓰지 않고 테마 순서와 문항 번호를 유지한다.

```bash
python run.py checkpoint --plan output/production_plan.json --state output/progress.json --status
```

5. 전체 구간 완료 후 원본 페이지와 최종 원고의 대응 관계를 최종 점검한다. **한 구간만 제작했을 때는 `--complete`를 사용하지 않는다.**

## 5. 내용 검증 및 PDF 생성

- 원고를 만든 뒤 계산·선지·정답·조건을 독립 검산한다. **집필 검증 기준**은 `개념설명_문제출제_지침.md` 참조. 원본의 **모든 논증·도출·증명 과정**은 `원본 페이지(내부 감사) → 개념다지기 → 마플특강 proof_questions[]` 경로로 전수 대조하고, **모든 공식·정리·관계식(증명 없는 항목 포함)** 은 `원본 페이지 → 개념다지기 sections[]` 경로로 별도 전수 대조한다.
- **유형별 문항 수 검사:** 각 `advanced_types[]`의 `question_indices`를 펼쳐 `advanced[]`의 존재하는 문항 중 **중복 없는 독립 문항 최소 3개**가 있는지, `s`·`a`·`e`가 갖춰졌는지 확인한다. 같은 인덱스 반복과 수치만 바꾼 복제 문항은 제외한다. 하나라도 미달이면 원고 미완료다.
- JSON을 저장하고 `python run.py validate content.json`을 실행한다. 실패하면 수정 후 재실행한다. **JSON 스키마 통과는 원본 논증·공식 누락이나 유형별 문항의 실질적 중복을 모두 검출하지 못할 수 있으므로**, 원본 전수 대조표 또는 유형별 3문항 검수표의 미완료 항목이 남아 있으면 교육 내용 검증은 통과로 표시하지 않는다.
- 전체 강의에 대한 엄격 검수(`--complete`)는 실제 전체 원본 대조를 수행하고 `meta.source_total_pages`, 모든 `source_pages`, `editorial.theme_plan`, `audit.coverage_reviewed` 등 감사 필드를 기록한 뒤에만 사용한다.
- 별도 `Pretendard-1.3.9.zip` 원본 폰트 경로를 확인한다. 패키지에는 폰트가 들어 있지 않다. 없으면 사용자에게 알린다.

```bash
python run.py build content.json --out output/workbook.pdf --font-zip /path/to/Pretendard-1.3.9.zip
```

- `.qa.json` 오류가 있다면 수정하고 다시 생성한다.
- `output/preview` 등 생성된 **모든 페이지 PNG**를 확대 확인한다. 수식 잘림·겹침, 개념 카드의 페이지 나눔, 번호·본문 기준선, 그래프/선지의 침범, 마플특강 풀이 위치, 하단 정답, 남은 공백을 점검한다.
- 페이지 배치는 AI가 보기 좋을 것이라고 추측해 지정하는 것이 아니라 **조판 엔진의 실제 크기 측정**에 맡긴다. QA의 `layout_metrics.concept_packing` 및 `concept_page_breaks`로 근거를 확인한다.
- 내용이 카드 높이를 넘는다면 **개념을 삭제하지 말고** 수학적 의미에 맞는 소절·카드로 분리한다.
- 실행 환경에 Python·TeX 도구가 없으면 PDF를 생성했다고 주장하지 않는다. 검증된 JSON 등 실제 만들 수 있었던 산출물만 제공한다.

## 6. 전달할 산출물

1. 원본 페이지 대응이 정확한 `content.json`.
2. 검증 완료된 문제집 PDF(실제 PDF 생성이 가능한 환경인 경우).
3. `.qa.json`과 전체 페이지 PNG 또는 contact sheet.
4. 원본 누락 점검표, **논증·유도별 마플특강 전수 대응표**, **증명 유무와 무관한 공식·정리·관계식의 개념다지기 전수 대응표**, **유형별 최소 3문항 검수표**, 검산 결과·미확인 사항 요약.
5. 여러 구간인 경우 현재 구간, 완료 범위, 다음 구간과 진행 상태.

**처리 시작 규칙:** ZIP과 강의노트가 주어지면 원본 전체 조사를 먼저 시작한다. 예제 데이터의 분량과 문제를 새 원본에 복사하지 않는다. JSON 작성 전 **독립 개념 설명·문제 출제 지침을 확인하는 것이 필수 단계**다. 완료 판정에는 **유형별 최소 3문항 + 원본 공식의 개념다지기 전수 수록 + 원본 논증의 마플특강 전수 수록** 세 항목이 모두 필요하다.
