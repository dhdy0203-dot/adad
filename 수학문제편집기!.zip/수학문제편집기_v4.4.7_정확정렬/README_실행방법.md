# 수학 문제 편집기 v4.4 — 수식 간격·표지 자동화·상세 예시 개선판

이 패키지는 기존 v4.3을 기반으로 **원고 JSON → 벡터 수식·그래프가 포함된 PDF**를 만드는 Python 조판 도구입니다. 자체 AI 모델은 포함하지 않습니다. 생성 결과는 참고 교재의 시각적 *구성 원리*를 응용하며, 원본 교재와 픽셀 단위로 동일하게 재현하는 프로그램이 아닙니다.

## 이번 버전의 변경 사항

1. **수식과 한글의 좌우 여백 균형**: 본문 중 `\( ... \)` 수식의 양옆 간격을 동일한 시각적 여백으로 정하고, 수식이 다음 줄로 넘어갈 때 왼쪽의 불필요한 간격을 제거했습니다. `마플특강`의 「정답 / 증명 풀이」 항목도 텍스트 시작 위치를 약 12pt 왼쪽으로 조정했습니다. 실제 렌더링 회귀 테스트가 포함됩니다.
2. **과목에 따라 바뀌는 표지**: 표지의 `ACTUARIAL STATISTICS` 하드코딩을 제거했습니다. 별도 설정이 없으면 `meta.cover.background_text → meta.subject → meta.cover_title → meta.title`을 참고하여 관련 표제 및 배경 장식 문구를 표시합니다. `meta.cover`에서 문구들을 항목별로 변경할 수 있습니다. 기존 `meta.cover_title`/`meta.chapter_code`/`meta.short_chapter` 사용법과 호환됩니다.
3. **새 상세 샘플**: `samples/상세예시_함수의극한.json`과 해당 PDF를 추가했습니다. 두 테마, 14문항, 개념 카드, 확인/변형/발전, 문제 유형 묶음, 마플특강, 해설, 핵심 공식, 가상 원고 페이지 연결, 그래프를 포함합니다.
4. **수학 그래프 표현 확장**: `figure.curves[]`를 활용한 여러 곡선, `figure.points[].open`을 활용한 열린 점, 점의 색/크기/라벨 배치 지원. 기존 `figure.curve`/`figure.points`도 그대로 동작합니다.

## 설치 및 실행

필요: Python 3.10+, pdflatex(TeX Live, standalone / amsmath / amssymb / mathtools), Python 패키지.

```bash
pip install -r requirements.txt
python run.py validate samples/상세예시_함수의극한.json
python run.py build samples/상세예시_함수의극한.json --out output/함수의극한.pdf --font-zip '/내/폰트/Pretendard-1.3.9.zip'
python tests/test_cover_and_math_spacing.py --font-zip '/내/폰트/Pretendard-1.3.9.zip'
```

**Pretendard 폰트는 저작물/재배포 정책상 이 ZIP에 포함하지 않았습니다.** 별도로 받은 ZIP을 `--font-zip`으로 지정해 주세요. 네 종류의 `.ttf`(Regular/Bold/Medium/SemiBold)를 `--font-dir` 폴더로 지정해도 됩니다. 대체 폰트를 사용하면 조판 길이가 달라질 수 있습니다.

## 주제별 표지 변경 예시

기존 `meta` 항목에 다음을 포함시키면 됩니다.

```json
{
  "meta": {
    "title": "미적분 연습 문제집",
    "cover_title": "미분과 도함수",
    "subject": "미적분",
    "short_chapter": "Ⅰ. 미분법",
    "chapter_code": "02",
    "source_title": "실제 강의 원고명",
    "source_total_pages": 40,
    "cover": {
      "background_text": "CALCULUS",
      "eyebrow": "MATHEMATICS · WORKBOOK",
      "unit_label": "CHAPTER",
      "unit_caption": "DERIVATIVES · PROBLEMS",
      "footer_caption": "CALCULUS PRACTICE SERIES",
      "contents_label": "목차 · 학습 테마"
    }
  }
}
```

`meta.cover`의 모든 값은 선택사항입니다. `cover.background_text`가 없으면 `meta.subject`를, `meta.subject`도 없으면 `meta.cover_title` 또는 `meta.title`을 자동 사용합니다. 긴 문구는 표지 너비에 맞게 글자 크기를 조정하고 필요하면 말줄임합니다. **원본 강의의 출처 정보는 실제 원본에 맞춰 입력해야 합니다.** 위의 `meta` 객체만 별도 JSON 파일로 저장해서는 PDF를 만들 수 없으며 `themes` 배열도 있어야 합니다.

## 예제 선택

- `samples/상세예시_함수의극한.json`: **신규 권장 예시**. 사용자 제공 교재 이미지는 디자인 방향의 참고 자료로만 사용하고, 문제·그래프·풀이 텍스트는 독립적으로 새로 작성했습니다. **실제 강의노트가 아니므로 `--complete`용 원본 검수 증빙으로 사용할 수 없습니다.**
- `samples/상세예시_함수의극한.pdf`: 위 JSON을 이 버전에서 직접 렌더링한 출력본(12페이지). `samples/상세예시_함수의극한.qa.json`에는 조판 검증 결과가 저장됩니다.
- `samples/미니샘플.json`: 기존의 보험통계학 가상 원고, 레거시 호환성 검사.
- `samples/샘플_작성가이드.md`: 새 예시 JSON의 계층, 그래프, 표지, 문항 작성 및 검수 가이드.
- `samples/production_plan_example.json`: 긴 강의를 여러 구간으로 편집하는 계획의 예시.

## 파일 구조

```text
run.py                                  검증/생성/원고 추출 명령
requirements.txt                        의존성
engine/                                 수식 및 본문 조판 엔진
schemas/content.schema.json             JSON 데이터 규격
samples/상세예시_함수의극한.json           추천 상세 예시 원고
samples/상세예시_함수의극한.pdf            상세 예시 출력본
samples/상세예시_함수의극한.qa.json        상세 예시 조판 검증 결과
samples/샘플_작성가이드.md                필드별 작성 방법
samples/미니샘플.*                        종전 예시(재빌드됨)
tests/test_cover_and_math_spacing.py     표지 / 수식 간격 회귀 검사
tools/validate_content.py               원고 유효성 검사
prompts/AI_JSON_WORKFLOW_KO.md          AI 작업 흐름·JSON·PDF 검증/조판 지침
prompts/개념설명_문제출제_지침.md           개념 설명·문제 출제 전용 지침 (독립 파일)
assets/mapl_reference/...png            기존 미리보기 캐릭터 이미지
```

## AI 지침 분리 (개념·출제 / 기술 작업 흐름)

- **개념 설명·문제 출제만 필요할 때:** [`prompts/개념설명_문제출제_지침.md`](prompts/개념설명_문제출제_지침.md)만 읽습니다. 개념의 깊이, 증명, 확인·변형·발전 3문항, 유형별 문제, 특강과 검산 원칙을 정합니다.
- **JSON 제작·PDF 조판할 때:** [`prompts/AI_JSON_WORKFLOW_KO.md`](prompts/AI_JSON_WORKFLOW_KO.md)를 추가로 읽습니다. 원본 추출, 필드 연결, 저장 형식, 실행 명령, QA 검수를 맡습니다.
- 조판 엔진이나 JSON 스키마는 변경하지 않았습니다. 기존 샘플과의 호환성을 유지하며, 교육 콘텐츠 집필 원칙만 독립 문서로 분리했습니다.

## 제작 시 검수 유의사항

- 원고 JSON은 `python run.py validate`를 먼저 통과해야 합니다. `build` 후 생성되는 `.qa.json`의 errors/warnings와 전체 페이지 이미지를 확인하세요.
- 출제한 문제의 수학적 정답, 논리적 증명, 강의 내용과의 일치성까지 자동으로 보장하지는 않습니다. 수학적 검수는 별도로 필요합니다.
- `\( ... \)`는 문장 속 수식, `\[ ... \]`는 단독 수식입니다. JSON 파일에는 `\\( ... \\)`처럼 백슬래시를 두 번 적어야 합니다.
- 원고가 너무 길어 카드 하나가 페이지에 들어가지 않으면 페이지 분리 또는 카드의 단락 분할이 필요할 수 있습니다.


## v4.4.1 추가 수정
- LaTeX 수식 조각의 좌우 숨은 여백을 잘라 inline 배치 들쭉날쭉 문제를 추가 개선했습니다.
- 개념 페이지가 길어져 이어질 때 상단의 `마플개념학습 XX ...` 배너를 더 이상 그리지 않습니다.


## v4.4.2 미세 정렬 보정
- `보기` 라벨과 예시 수식 사이 간격을 줄이고, 예시 번호와 본문 baseline을 맞췄습니다.
- 확인/변형/발전 문제의 번호와 본문 baseline을 소폭 상향 보정했습니다.
- 하단 `정답` 스트립에서 실제 정답 baseline을 올리고, 정답 항목 사이 간격을 넓혔습니다.


## v4.4.3 기준선 정렬 검수판 (추가 수정)
- 텍스트와 큰 LaTeX 수식을 한 줄에 그릴 때 수식 높이가 첫 줄의 한글 글자를 아래로 밀던 원인을 제거했습니다. 첫 줄은 지정된 텍스트 기준선에 고정하며, 수식의 위쪽 돌출 부분은 별도의 블록 높이로 보전합니다.
- 증명/개념 보기의 `01`과 본문, 확인/변형/발전 문제의 문항 번호와 본문을 실제 PDF 기준선으로 검사합니다.
- 하단 정답을 공백으로 이어 붙이지 않고 최대 3개의 독립적인 열로 배치합니다. 항목이 길면 다음 줄로 내려갑니다.
- 수식집의 연속된 긴 수식에 추가 세로 여유를 주어 수식 사이 겹침을 방지했습니다.
- 새 테스트: `python tests/test_rendered_alignment.py samples/상세예시_함수의극한.pdf` (실제 글리프 원점 좌표 검사).
- 검수 결과: 상세 예제 12페이지·14문항, 미니 예제 7페이지·4문항, 두 샘플의 조판 오류 0건 / 경고 0건.
- 시각 검수 자료: `samples/정렬검수_확대.png`


## v4.4.4 마감 보정
- 확인/변형/발전 문제 라벨과 번호 사이 간격을 추가로 줄였습니다.
- 하단 정답 스트립의 각 항목을 셀 기준으로 더 안정적으로 중앙 배치했습니다.
- `개념익힘풀이` 라벨 박스를 텍스트 폭 기준으로 다시 계산해 좌우 여백을 균형 있게 맞췄습니다.
- 유형 카드에서 그래프가 본문/구분선을 침범하지 않도록 그래프가 있는 경우 텍스트 사용 폭을 별도로 제한했습니다.
- `0/0`은 분수 LaTeX 대신 일반 텍스트 라벨로 처리해 작게 깨져 보이는 현상을 없앴습니다.


## v4.4.5 최종 미세 수정
- 그래프가 포함된 유형 문제에서는 선지가 그래프 아래에서 시작되도록 조정해 그래프 중복/침범을 막았습니다.
- 하단 정답 스트립의 정답 항목을 `정답` 라벨과 같은 줄에 오도록 재정렬했습니다.


## v4.4.7 정확 정렬 보정
- 같은 그래프가 유형 소개와 그 유형의 번호 문제에 동시에 등록된 경우, 번호 문제에만 표시합니다.
- 하단 정답 문자열은 `정답` 라벨과 정확히 같은 기준선으로 출력하고 바로 오른쪽(85pt)에서 시작합니다.

## 학생용 표기 및 마플특강 규칙
- 학생용 PDF에 F/D 감사 코드, [원본:페이지] 태그, (계속) 꼬리표 금지. 감사 자료에는 보존 가능.
- 마플특강은 증명 연습 문제 → 약 8cm 이상의 충분한 필기 공간 → 증명 해설, 3단 구성만 출력.
- 원문에 없는 전문용어는 임의로 생성하지 않음.
