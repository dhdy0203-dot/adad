"""Real LaTeX -> tightly cropped *vector PDF* snippets.

JSON formulas are never sent to the workbook as raw backslash text.  A local
pdflatex executable compiles them using the standard LaTeX math environment;
the resulting PDF pages are placed into the original workbook's vector pages.
No shell escape, no rasterization, cached by exact expression.
"""
from pathlib import Path
import hashlib
import re
import subprocess
import tempfile

import fitz

class LatexRenderError(RuntimeError):
    pass

# Block access to arbitrary TeX files/processes and defining arbitrary macros.
FORBIDDEN = re.compile(r'\\(?:input|include|openin|openout|read|write|immediate|catcode|def|gdef|edef|xdef|newcommand|renewcommand|documentclass|usepackage|special|pdfobj|pdfximage|loop|repeat|csname|endcsname)\b', re.I)

class LatexVectorStore:
    def __init__(self):
        self._temp = tempfile.TemporaryDirectory(prefix='workbook_math_')
        self.root = Path(self._temp.name)
        self.cache = {}
        if not subprocess.run(['which', 'pdflatex'], capture_output=True).returncode == 0:
            raise LatexRenderError('pdflatex executable required (TeX Live).')

    def close(self):
        self._temp.cleanup()

    def get(self, expression):
        if not isinstance(expression, str) or not expression.strip():
            raise LatexRenderError('LaTeX formula must be a non-empty string.')
        # Inline wrappers are handled by the calling text lexer.
        expression = expression.strip()
        if FORBIDDEN.search(expression):
            raise LatexRenderError('Disallowed command in LaTeX formula.')
        if expression in self.cache:
            return self.cache[expression]
        key = hashlib.sha256(expression.encode('utf-8')).hexdigest()[:18]
        work = self.root / key
        work.mkdir(exist_ok=True)
        doc = (r'\documentclass[border=0pt]{standalone}' '\n'
               r'\usepackage[T1]{fontenc}' '\n'
               r'\usepackage{amsmath,amssymb,bm,mathtools}' '\n'
               r'\pagestyle{empty}' '\n'
               r'\begin{document}' '\n'
               # Preserve TeX's true math axis and baseline. Standalone crops
               # the PDF tightly, but its PDF height alone cannot tell us how
               # much lies BELOW the mathematical baseline (fractions, sums).
               r'\setbox0=\hbox{$\displaystyle ' + expression + r'$}' '\n'
               r'\typeout{WORKBOOK-MATH-ASCENT=\the\ht0}' '\n'
               r'\typeout{WORKBOOK-MATH-DESCENT=\the\dp0}' '\n'
               r'\box0' '\n'
               r'\end{document}' '\n')
        (work / 'formula.tex').write_text(doc, encoding='utf-8')
        cmd = ['pdflatex', '-no-shell-escape', '-halt-on-error', '-interaction=nonstopmode', '-output-directory', str(work), str(work / 'formula.tex')]
        try:
            completed = subprocess.run(cmd, cwd=work, capture_output=True, text=True, timeout=20)
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise LatexRenderError(f'LaTeX compiler unavailable/timed out: {exc}') from exc
        pdfpath = work / 'formula.pdf'
        if completed.returncode or not pdfpath.is_file():
            tail = (completed.stdout + '\n' + completed.stderr)[-1800:]
            raise LatexRenderError('Invalid LaTeX formula: ' + repr(expression) + '\n' + tail)
        with fitz.open(pdfpath) as pdf:
            if len(pdf) != 1:
                raise LatexRenderError('Math renderer must return exactly one page.')
            page = pdf[0]
            rect = page.rect
            if not 0 < rect.width < 1500 or not 0 < rect.height < 300:
                raise LatexRenderError(f'Suspicious formula dimensions {rect}.')
            # Standalone TeX pages often keep a noticeable left side-bearing
            # even with border=0pt.  In Korean prose this makes inline math look
            # detached from surrounding text.  Trim ONLY horizontal blank margin;
            # keep the full vertical extent so baseline metrics remain exact.
            boxes = []
            try:
                for block in page.get_text('dict').get('blocks', []):
                    if 'lines' in block:
                        boxes.append(fitz.Rect(block['bbox']))
            except Exception:
                pass
            try:
                for drawing in page.get_drawings():
                    r = drawing.get('rect')
                    if r is not None:
                        boxes.append(fitz.Rect(r))
            except Exception:
                pass
            if boxes:
                union = fitz.Rect(boxes[0])
                for box in boxes[1:]:
                    union |= fitz.Rect(box)
                clip_x0 = max(0.0, min(rect.width - 0.8, union.x0 - 0.45))
                clip_x1 = min(rect.width, max(clip_x0 + 0.8, union.x1 + 0.45))
            else:
                clip_x0, clip_x1 = 0.0, rect.width
            clip_rect = fitz.Rect(clip_x0, 0.0, clip_x1, rect.height)
            dims = (clip_rect.width, rect.height)
        # TeX reports pt (72.27/in), whereas PyMuPDF uses PDF bp (72/in).
        # Convert before planning line boxes, so normal text and math use the
        # same baseline in the final PDF, even when the formula has depth.
        def read_dimension(name):
            match = re.search(r'WORKBOOK-MATH-' + name + r'=([0-9.]+)pt', completed.stdout)
            if not match:
                raise LatexRenderError('Missing TeX baseline metric for '+repr(expression))
            return float(match.group(1)) * (72.0 / 72.27)
        ascent = read_dimension('ASCENT')
        descent = read_dimension('DESCENT')
        # The cropped PDF page normally equals ascent + descent, differing by
        # only roundoff. Reject unexpected extra padding rather than misalign.
        if abs((ascent + descent) - dims[1]) > 0.20:
            raise LatexRenderError('LaTeX box height disagrees with baseline metrics for '+repr(expression))
        self.cache[expression] = (pdfpath, *dims, ascent, descent, tuple(clip_rect))
        return self.cache[expression]

    def measure(self, expression, scale=1.0):
        _, w, h, _, _, _ = self.get(expression)
        return w * scale, h * scale

    def measure_box(self, expression, scale=1.0):
        """PDF width, PDF height, ascent, descent in ReportLab points."""
        _, w, h, a, d, _ = self.get(expression)
        return (w * scale, h * scale, a * scale, d * scale)

# Supports familiar LaTeX inline and display syntax, with a conservative $...$ alias.
TOKEN = re.compile(r'\\\[(.*?)\\\]|\\\((.*?)\\\)|\$\$(.*?)\$\$|(?<!\\)\$(.+?)(?<!\\)\$', re.S)

def segments(value):
    """Yield (kind, content), where kind is text, inline_math or display_math."""
    if isinstance(value, dict):
        if 'latex' in value:
            return [('display_math' if value.get('display', True) else 'inline_math', value['latex'])]
        value = value.get('text', '')
    if not isinstance(value, str):
        value = str(value)
    result=[]
    last=0
    for match in TOKEN.finditer(value):
        if match.start()>last:
            result.append(('text', value[last:match.start()]))
        result.append(('display_math' if match.group(1) is not None or match.group(3) is not None else 'inline_math', next(x for x in match.groups() if x is not None)))
        last=match.end()
    if last<len(value):
        result.append(('text', value[last:]))
    return result or [('text','')]

def has_latex(value):
    return any(k != 'text' for k, _ in segments(value))
