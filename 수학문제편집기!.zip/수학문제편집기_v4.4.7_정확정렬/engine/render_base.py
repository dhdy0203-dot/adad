"""Core vector PDF primitives for the MAPL-style workbook layout only."""
from __future__ import annotations
import json, io, math, re
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import simpleSplit
import fitz
from engine.latex_renderer import LatexVectorStore, LatexRenderError, segments, has_latex

ROOT=Path(__file__).resolve().parents[1]
W,H=540,720
FONTDIR=Path('/usr/share/fonts/truetype/nanum')
COLORS={'ink':'#272727','orange':'#F47710','red':'#D65129','teal':'#167E74','secondary':'#65615E','white':'#FFFFFF','rule':'#B5B2AA'}
CIRCLES='①②③④⑤⑥⑦⑧⑨⑩'
FONTS={'r':('NanumGothic','NanumGothic.ttf'),'b':('NanumGothicBold','NanumGothicBold.ttf'),'s':('NanumSquareR','NanumSquareR.ttf'),'sb':('NanumSquareB','NanumSquareB.ttf')}

class BuildError(RuntimeError):
    pass

class Engine:
 def __init__(self,data,out,strict=True,fontdir=FONTDIR,register_legacy_fonts=True):
  self.data=data;self.out=Path(out);self.strict=strict;self.errors=[];self.warnings=[];self.pages=[];self.qpairs=[];self.nextid=1;self.math_placements=[];self.latex=LatexVectorStore()
  self.fonts=FONTS
  if register_legacy_fonts:
   for alias,(n,p) in self.fonts.items():
    f=Path(fontdir)/p
    if not f.exists():raise BuildError(f'Nanum 폰트 필요: {f}. 해당 폰트를 사용자가 설치해야 원본 자간이 유지됩니다.')
    if n not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(n,str(f)))
  self.out.parent.mkdir(parents=True,exist_ok=True)
  self.buf=io.BytesIO();self.c=canvas.Canvas(self.buf,pagesize=(W,H),pageCompression=1)
  self.c.setTitle(self.data['meta']['title']+' | 원본벡터 마스터')
 def tx(self,x,y,s,font='r',size=9.8,color='ink',max_width=None,align='left'):
  s=str(s)
  name=self.fonts[font][0]
  width=pdfmetrics.stringWidth(s,name,size)
  if max_width and width>max_width: # Do NOT quietly squish below readable min.
   self.errors.append({'type':'title_too_long','text':s[:80],'actual_pt':round(width,2),'max_pt':max_width,'page':len(self.pages)+1})
  self.c.setFont(name,size);self.c.setFillColor(HexColor(COLORS[color]));xx=x
  if align=='right':xx=x-width
  if align=='center':xx=x-width/2
  self.c.drawString(xx,H-y,s)
  return width
 def wrap(self,s,font='r',size=9.75,width=280):
  return [line for part in str(s).split('\n') for line in (simpleSplit(part,self.fonts[font][0],size,width) if part else [''])]
 def paragraph(self,x,baseline,s,width,size=9.75,leading=14.6,font='r',color='ink',limit=None):
  for line in self.wrap(s,font,size,width):
   if limit and baseline>limit:
    self.errors.append({'type':'text_overflow','text':str(s)[:80],'page':len(self.pages)+1,'at':round(baseline,1),'limit':limit})
   self.tx(x,baseline,line,font,size,color);baseline+=leading
  return baseline
 def rich(self,x,baseline,value,width,size=9.75,leading=14.6,font='r',color='ink',limit=None,dry=False):
  """Measure and draw prose/math through one line-box planner.

  Each TeX box contributes its true ascent, descent and width. The following
  baseline is moved down enough to avoid the previous row's ink. Measurements
  and actual placement follow exactly the same plan for dry and live passes.
  """
  raw=value.get('text','') if isinstance(value,dict) and 'latex' not in value else value
  if isinstance(raw,str):
   # A JSON \f or \b instead of \\frac / \\bar produces control chars.
   if any(ch in raw for ch in ('\x0c','\x08','\x00','\x0b')):
    raise BuildError('LaTeX JSON escape error (control character). Escape formula backslashes as \\ in JSON; use \\( ... \\).')
  if not has_latex(value):
   txt=raw if isinstance(raw,str) else str(raw)
   if re.search(r'\\(?:frac|dfrac|tfrac|sum|int|lambda|qquad|hat|bar|sqrt|overline|alpha|beta|sigma|left|right|begin|mathrm|text|displaystyle)\b',txt):
    raise BuildError('Unwrapped LaTeX command in plain text: use \\( ... \\) or {"latex":"..."} so it cannot print as literal text.')
   lines=self.wrap(txt,font,size,width)
   for line in lines:
    if limit is not None and baseline>limit and not dry:self.errors.append({'type':'text_overflow','page':len(self.pages),'at':round(baseline,1),'limit':limit})
    if not dry:self.tx(x,baseline,line,font,size,color)
    baseline+=leading
   return baseline
  fontname=self.fonts[font][0]
  chunks=[]
  segs=list(segments(value))
  # Keep the gap on BOTH sides of inline mathematics optically balanced.
  # The original planner could strand a gap at the start/end of a wrapped line,
  # producing the apparent large left indent shown in mixed Korean/TeX prose.
  # All leading/trailing plain spaces at a math boundary are replaced by a
  # single, symmetric optical gap in points (not a full Korean character).
  math_side_pad=max(1.9, size*0.24)
  for idx,(kind,piece) in enumerate(segs):
   prev_kind=segs[idx-1][0] if idx>0 else None
   next_kind=segs[idx+1][0] if idx+1<len(segs) else None
   if kind=='text':
    if re.search(r'\\(?:frac|sum|int|lambda|qquad|sqrt|hat|bar)\b',piece):
     raise BuildError('Unwrapped LaTeX command next to an equation; wrap the entire expression in \\( ... \\).')
    if prev_kind in ('inline_math','display_math'):
     piece=re.sub(r'^[ \t]+','',piece)
    if next_kind in ('inline_math','display_math'):
     piece=re.sub(r'[ \t]+$','',piece)
    for word in re.split(r'(\n|[ \t]+)',piece):
     if word=='\n':chunks.append(('newline','',0,0,0,0));continue
     if word:chunks.append(('text',word,pdfmetrics.stringWidth(word,fontname,size),size,size*.86,size*.24))
   else:
    try: realw,realh,realas,realds=self.latex.measure_box(piece,scale=size/10.0)
    except LatexRenderError as ex:raise BuildError(str(ex)) from ex
    shrink=min(1.0,width/realw) if realw else 1.0
    if shrink<0.64:
     raise BuildError(f'LaTeX formula too wide for {width:.0f}pt; split the formula into aligned lines: {piece[:80]}')
    # Pads travel with each math box and are cleaned at line boundaries below.
    # This keeps measurement identical in live and dry runs.
    if kind=='inline_math' and prev_kind=='text' and segs[idx-1][1].strip():
     chunks.append(('gap','',math_side_pad,0,0,0))
    chunks.append((kind,piece,realw*shrink,realh*shrink,realas*shrink,realds*shrink))
    if kind=='inline_math' and next_kind=='text' and segs[idx+1][1].strip():
     chunks.append(('gap','',math_side_pad,0,0,0))
  rows=[];cur=[];roww=0
  def finish():
   nonlocal cur,roww
   # Discard edge space/gap when a text-math pair moves to the next line.
   # No left-indented math or invisible padding at the right margin.
   while cur and (cur[-1][0]=='gap' or (cur[-1][0]=='text' and cur[-1][1].isspace())):
    cur.pop()
   if cur:rows.append(cur)
   cur=[];roww=0
  for kind,piece,w,h,a,d in chunks:
   if kind=='newline':finish();rows.append([]);continue
   if kind=='display_math':finish();rows.append([(kind,piece,w,h,a,d)]);continue
   if kind=='text' and w>width+0.05:
    if not dry:self.errors.append({'type':'long_unbreakable_word','page':len(self.pages),'text':piece[:80]})
   if cur and roww+w>width+0.05:
    finish()
   if not cur and (kind=='gap' or (kind=='text' and piece.isspace())):
    continue
   cur.append((kind,piece,w,h,a,d));roww+=w
  finish()
  if not rows:rows=[[]]
  last_base=None;prev_descent=size*.24
  initial=baseline;first_ascent_bonus=0.0
  for row in rows:
   # The TeX box reports true height ABOVE and depth BELOW its own baseline.
   # Use the SAME baseline as ReportLab's Korean text rather than the old
   # constant-descent approximation (which raised fractions and sums).
   ascent=max([size*.86]+[a for kind,_,w,h,a,d in row if kind not in ('text','gap')])
   descent=max([size*.24]+[d for kind,_,w,h,a,d in row if kind not in ('text','gap')])
   if last_base is None:
    # Treat baseline as the actual Korean text baseline. Older behavior
    # shifted the *whole* line down by the math ascent, causing text next
    # to fractions/cases to sit below fixed labels and exercise numbers.
    # Math may extend above this baseline; reserve vertical space for the
    # following row using descent/ascent, but never move Korean text down.
    current=initial
    # Preserve the pre-fix block HEIGHT in the flow planner, even though
    # the visible Korean baseline stays fixed.  This keeps adjacent math
    # blocks in the formula appendix from overlapping after realignment.
    first_ascent_bonus=max(0.0,ascent-size*.86)
   else:
    current=last_base+max(leading,prev_descent+ascent+2.8)
   if limit is not None and current+descent>limit and not dry:
    self.errors.append({'type':'latex_text_overflow','page':len(self.pages),'limit':limit,'at':round(current,1)})
   xx=x
   for kind,piece,w,h,a,d in row:
    if kind=='text':
     if not dry and piece.strip():self.tx(xx,current,piece,font,size,color)
    elif kind=='gap':
     pass
    else:
     top=current-a
     if not dry:
      self.math_placements.append({'page':len(self.pages)-1,'latex':piece,
                                   'rect':[xx,top,xx+w,top+h],
                                   'baseline':current,'ascent':a,'descent':d})
    xx+=w
   last_base=current;prev_descent=descent
  # Leave enough space below large fractions/summations before the next block.
  return last_base+max(leading,prev_descent+size*.86+2.8)+first_ascent_bonus
 def page(self,role,theme):self.pages.append({'role':role,'theme':theme,'number':len(self.pages)+1})
 def end(self):self.c.showPage()
 def footer(self,number,right=False):
  short=self.data['meta'].get('short_chapter','I. 학습 개념');book=self.data['meta'].get('title','학습 문제집');book=str(self.data['meta'].get('chapter_code','01'))+' '+book
  if right:
   self.tx(501,712.6,str(number),'sb',11,align='right')
   self.tx(473,710,book,'s',7.7,align='right',max_width=160)
  else:
   self.tx(36,709.56,str(number),'sb',11)
   self.tx(66,709.87,short,'s',8.2,max_width=255)
 def append_solutions(self):
  self.page('answers','정답과 해설')
  self.tx(39,52,'C  정답과 상세 해설','sb',21,'orange')
  self.tx(500,52,self.data['meta']['title'],'sb',9,'secondary',align='right')
  self.c.setStrokeColor(HexColor('#CBC3B8'));self.c.line(38,H-68,502,H-68)
  pos=0;y=101
  for no,theme,q,kind in self.qpairs:
   answer=q['a']; explanation=q['e']; w=210
   h_answer=self.rich(0,0,answer,w,8.7,14,'b',dry=True)
   h_explain=self.rich(0,0,explanation,w,8.1,12,'r',dry=True)
   need=17+h_answer+h_explain+13
   if y+need>670:
    if pos==0:pos=1;y=101
    else:
     self.footer(self.data['meta'].get('page_number_start',8)+len(self.pages)-1);self.end()
     self.page('answers','정답과 해설');pos=0;y=66
   x=38 if pos==0 else 277
   self.tx(x,y,f'{no:04d}  정답','b',8.8,'orange');y+=16
   y=self.rich(x,y,answer,w,8.7,14,'b','orange')
   y=self.rich(x,y+3,explanation,w,8.1,12,'r')+13
  self.footer(self.data['meta'].get('page_number_start',8)+len(self.pages)-1);self.end()
  self.page('formula','공식집')
  self.tx(37,53,'핵심 공식 · 원본 강의노트 대응','sb',18,'orange');y=93
  for i,t in enumerate(self.data['themes'],1):
   fs=t.get('formula',[])
   lineheight=sum(self.rich(0,0,s,435,9.0,14,'r',dry=True)+6 for s in fs)
   needed=21+lineheight+12
   if y+needed>669:
    self.footer(self.data['meta'].get('page_number_start',8)+len(self.pages)-1);self.end()
    self.page('formula','공식집');y=70
   self.tx(43,y,f'{i:02d} {t["title"]}   |  원본 {t.get("pages","검토 필요")}', 'sb',9.8,'teal');y+=20
   for s in fs:
    self.tx(47,y,'·','r',9.0)
    y=self.rich(58,y,s,435,9.0,14,'r')+6
   y+=12
  self.footer(self.data['meta'].get('page_number_start',8)+len(self.pages)-1);self.end()
