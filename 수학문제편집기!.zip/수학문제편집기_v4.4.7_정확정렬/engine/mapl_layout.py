"""Reference-inspired, content-driven MAPL concept/type spreads.

This layout never pastes a full-page reference screenshot. Text and diagrams remain
selectable/vector. The only reference-derived raster is an optional small mascot,
clearly marked as a preview asset. Original v3 engine is kept separately.
"""
from __future__ import annotations

import math
import io
import re
import os
import zipfile
from pathlib import Path
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas as pdf_canvas

from engine.render_base import Engine, BuildError, COLORS, W, H, CIRCLES, ROOT
from engine.latex_renderer import segments

COLORS.update({
    'm_teal':'#00AB9C','m_blue':'#008CCC','m_orange':'#F08A17',
    'm_lime':'#DAE600','m_pink':'#E30063','m_light':'#F3F8F7',
    'm_gray':'#606060','m_rule':'#C5E5E6','m_text':'#222222',
    'm_pale':'#F8F9F8','m_leaf':'#58B686', '#FFDE00':'#FFDE00',
    'm_exercise_rule':'#69B8CC', # browser-safe contrast for exercise rules

})

class MaplEngine(Engine):
    """Optional special lessons, overflow-safe concept and problem pages.

    Content controls special lessons. A document AI/editor decides whether a
    substantial derived topic merits a special lecture and supplies its text.
    Renderer does not hallucinate one merely from a keyword.
    """
    def __init__(self,*args,pretendard_zip=None,font_dir=None,**kwargs):
        super().__init__(*args,register_legacy_fonts=False,**kwargs)
        # Preserve Pretendard first. Other installed fonts are a clearly reported
        # fallback only; font files are never included in redistributed ZIPs.
        path = pretendard_zip or os.environ.get('PRETENDARD_ZIP')
        if not path:
            for base in (ROOT, ROOT.parent, Path('/mnt/data')):
                matches=sorted(base.glob('*Pretendard*.zip'))
                if matches:path=matches[0];break
        weights={'r':'Regular','b':'Bold','s':'Medium','sb':'SemiBold'}
        self.fonts={};self.font_source=None
        sources={}
        if path:
            path=Path(path)
            if not path.is_file():raise BuildError(f'Provided font ZIP not found: {path}')
            try:
                with zipfile.ZipFile(path) as z:
                    names=z.namelist()
                    for alias,weight in weights.items():
                        choices=[n for n in names if n.lower().endswith('pretendard-'+weight.lower()+'.ttf')]
                        if not choices:raise BuildError(f'Pretendard ZIP missing Pretendard-{weight}.ttf')
                        sources[alias]=io.BytesIO(z.read(choices[0]))
            except (KeyError,zipfile.BadZipFile) as exc:
                raise BuildError(f'Cannot read Pretendard ZIP: {exc}') from exc
            self.font_source='Pretendard (user-supplied ZIP)'
        else:
            folders=[Path(font_dir)] if font_dir else []
            folders += [ROOT/'fonts',ROOT.parent/'fonts',Path('/mnt/data/fonts')]
            for folder in folders:
                if not folder.is_dir():continue
                matches={k:next(iter(folder.rglob(f'Pretendard-{v}.ttf')),None) for k,v in weights.items()}
                if all(matches.values()):
                    sources=matches;self.font_source='Pretendard (user-supplied directory)';break
            if not sources:
                base=Path('/usr/share/fonts/truetype/nanum')
                names={'r':'NanumGothic.ttf','b':'NanumGothicBold.ttf','s':'NanumSquareR.ttf','sb':'NanumSquareB.ttf'}
                if all((base/name).is_file() for name in names.values()):
                    sources={k:base/v for k,v in names.items()};self.font_source='Nanum (fallback — Pretendard not provided)'
                    self.warnings.append({'type':'font_fallback','message':'Pretendard not found; temporary Nanum fallback used. Provide --font-zip or --font-dir for original typography.'})
                else:
                    raise BuildError('Pretendard fonts not found. Supply --font-zip or --font-dir (Regular/Bold/Medium/SemiBold TTF).')
        for alias,weight in weights.items():
            family='FactoryWorkbook'+weight
            if family not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(TTFont(family,sources[alias]))
            self.fonts[alias]=(family,str(sources[alias]))
        self.type_counter=0
        self.style_checks=[]
        self.preview_mascot=ROOT/'assets/mapl_reference/reference_mascot_preview.png'
        self.layout_metrics={'concept_cards':[], 'exercise_blocks':[], 'type_blocks':[]}

    # Convert common underscored variables in ordinary Korean prose to live
    # vector LaTeX. Explicit formulas are left untouched and never double wrapped.
    _plain_subscript = re.compile(r'(?<![\w\\])([A-Za-z])_([A-Za-z0-9]+)')

    def _normalize_prose_math(self, value):
        if isinstance(value, dict):
            if 'latex' in value:return value
            if 'text' in value:
                return dict(value, text=self._normalize_prose_math(value['text']))
            return value
        if not isinstance(value, str):return value
        parts=[]
        for kind, content in segments(value):
            if kind=='text':
                parts.append(self._plain_subscript.sub(lambda m: r'\('+m.group(1)+'_{'+m.group(2)+r'}\)',content))
            elif kind=='display_math':parts.append(r'\['+content+r'\]')
            else:parts.append(r'\('+content+r'\)')
        return ''.join(parts)

    def rich(self,x,baseline,value,width,size=9.75,leading=14.6,font='r',color='ink',limit=None,dry=False):
        return super().rich(x,baseline,self._normalize_prose_math(value),width,size,leading,font,color,limit,dry)

    def fill(self,x,y,w,h,c,rad=0,stroke=None,sw=.6):
        self.c.saveState()
        self.c.setFillColor(HexColor(COLORS.get(c,c)))
        if stroke:
            self.c.setStrokeColor(HexColor(COLORS.get(stroke,stroke)))
            self.c.setLineWidth(sw)
        if rad:self.c.roundRect(x,H-y-h,w,h,rad,stroke=int(bool(stroke)),fill=1)
        else:self.c.rect(x,H-y-h,w,h,stroke=int(bool(stroke)),fill=1)
        self.c.restoreState()

    def line(self,x1,y1,x2,y2,color='m_rule',sw=.7):
        self.c.saveState();self.c.setStrokeColor(HexColor(COLORS.get(color,color)))
        self.c.setLineWidth(sw);self.c.line(x1,H-y1,x2,H-y2);self.c.restoreState()

    def _answer_entry_width(self, content, size=7.15):
        """Approximate the width of a single answer without merging adjacent IDs."""
        font=self.fonts['r'][0]
        natural=0.0
        for kind,part in segments(content):
            if kind=='text':
                natural+=pdfmetrics.stringWidth(part,font,size)
            else:
                mw,_,_,_=self.latex.measure_box(part,scale=size/10.0)
                natural+=mw+2*max(1.9,size*.24)
        return natural

    def _answer_rows(self, answers, area_width=389, size=7.15):
        """Uniform columns, no fragile runs of spaces between answers.

        Pack at most three answers per row; move long answers to a new row
        rather than squeezing numbers together or truncating solutions.
        """
        def answer_value(v):
            if isinstance(v,dict):
                if 'latex' in v:return r'\('+v['latex']+r'\)'
                return v.get('text','')
            return str(v)
        entries=[]
        for no,a in answers:
            content=f'{no:04d}  {answer_value(a)}'
            entries.append((content,self._answer_entry_width(content,size)))
        rows=[]
        while entries:
            count=min(3,len(entries))
            while count>1 and any(w>area_width/count-5 for _,w in entries[:count]):
                count-=1
            if entries[0][1]>area_width-6:
                self.errors.append({'type':'answer_entry_too_wide','page':len(self.pages),'answer':entries[0][0][:65]})
            rows.append(entries[:count]);entries=entries[count:]
        return rows

    def frame_footer(self,kind='concept',answers=None):
        pn=self.data['meta'].get('page_number_start',10)+len(self.pages)-1
        if answers:
            rows=self._answer_rows(answers)
            text_size=7.15
            leading=11.5
            # measure content boxes row-by-row so entries can be centered inside their cells
            measured=[]
            row_heights=[]
            for row in rows:
                column_width=397/len(row)
                row_cells=[]
                max_h=0
                for value,est_w in row:
                    cell_w=column_width-5
                    content_h=self.rich(0,0,value,cell_w,text_size,leading,dry=True)
                    row_cells.append((value,est_w,content_h,cell_w))
                    max_h=max(max_h,content_h)
                row_h=max(18, max_h+4)
                measured.append((column_width,row_h,row_cells))
                row_heights.append(row_h)
            content_height=sum(row_heights)
            height=max(22,10+content_height+6)
            if height>50:
                self.errors.append({'type':'answer_strip_too_tall','page':len(self.pages),'height':round(height,1)})
            top=684-height
            self.fill(51,top,438,684-top,'#F6FDFD')
            self.line(51,top,489,top,'m_exercise_rule',1.15)
            self.line(51,684,489,684,'m_exercise_rule',1.15)
            strip_mid=(top+684)/2.0
            label_y=strip_mid+2.6
            self.tx(57,label_y,'정답','b',8,'m_blue')
            # rich() and tx() both accept the PDF text baseline directly.
            # Never derive it from line-box height: that had moved values
            # above the blue `정답` label. Keep the first value immediately
            # to the right of the label instead of centering it in a wide cell.
            if len(measured)==1:
                row_baselines=[label_y]
            else:
                group_height=sum(row_heights)
                first=strip_mid-group_height/2 + row_heights[0]*0.70
                row_baselines=[]
                for row_h in row_heights:
                    row_baselines.append(first)
                    first+=row_h
            for (column_width,row_h,row_cells),row_y in zip(measured,row_baselines):
                for i,(value,est_w,content_h,cell_w) in enumerate(row_cells):
                    cell_x=85+i*column_width
                    self.rich(cell_x,row_y,value,cell_w,text_size,leading)
        else:
            self.line(51,686,489,686,'m_exercise_rule' if kind=='exercise' else 'm_rule',
                      1.05 if kind=='exercise' else .45)
        right=len(self.pages)%2==0
        if right:
            self.tx(490,704,f'{pn:02d}','s',9,'m_teal',align='right')
            self.tx(483,694,self.data['meta'].get('short_chapter','개념 학습'),'r',6.9,'m_gray',align='right')
        else:
            self.tx(50,704,f'{pn:02d}','s',9,'m_teal')
            self.tx(70,704,self.data['meta'].get('short_chapter','개념 학습'),'r',6.9,'m_gray')

    def side_index(self,n):
        self.fill(521,126,19,62,'m_lime',rad=9)
        self.c.saveState();self.c.translate(525,H-143);self.c.rotate(-90)
        self.c.setFillColor(HexColor('#FFFFFF'));self.c.setFont(self.fonts['sb'][0],12)
        self.c.drawString(-30,0,f'{n:02d}');self.c.restoreState()
        self.c.saveState();self.c.translate(524,H-194);self.c.rotate(-90)
        self.c.setFillColor(HexColor(COLORS['m_gray']));self.c.setFont(self.fonts['r'][0],7.1)
        self.c.drawString(-45,0,'학습 개념');self.c.restoreState()

    def chapter_head(self,t,n,continuation=False):
        if not continuation:
            if self.preview_mascot.exists() and self.data.get('meta',{}).get('reference_mascot_preview',True):
                self.c.drawImage(ImageReader(str(self.preview_mascot)),45,H-82,width=101,height=81,mask='auto',preserveAspectRatio=True)
            else:
                raise BuildError('Mascot image missing: assets/mapl_reference/reference_mascot_preview.png. No substitute logo will be drawn.')
            self.tx(153,68,f'{n:02d}','sb',44,'m_teal')
            self.tx(233,37,'M A P L : Y O U R  M A S T E R  P L A N','r',6.3,'m_orange')
            self.tx(234,61,t['title'],'sb',19.7,'m_text',max_width=265)
        else:
            # Removed by request: the full-width continuation banner
            # "마플개념학습 XX ..." should not appear on split concept pages.
            pass
        if (self.data['meta'].get('page_number_start',10)+len(self.pages)-1)%2:
            self.side_index(n)

    def compact_heading(self,t,n,label='마플개념익힘'):
        # The entire pink unit number belongs to the WHITE segment. Neither
        # bounding box nor letter ink may straddle the white/blue boundary.
        x,y=51,44
        white_end=165
        self.fill(x,y,438,22,'m_blue')
        self.fill(x,y,white_end-x,22,'white')
        self.tx(58,58.2,label,'sb',10.0,'m_blue')
        digits=f'{n:02d}'
        self.tx(white_end-7,59.0,digits,'sb',15.2,'m_pink',align='right')
        self.tx(177,58.1,t['title'],'sb',9.5,'white',max_width=300)
        self.layout_metrics.setdefault('header_boxes',[]).append({
            'page':len(self.pages),'white_end':white_end,
            'unit_right':white_end-7,'title_left':177})
        self.side_index(n)

    def _h(self,value,width=375,size=8.2,leading=12.5):
        return self.rich(0,0,value,width,size,leading,dry=True)

    def _paragraph(self,x,y,content,width,size=8.2,leading=12.5,font='r',color='m_text'):
        return self.rich(x,y,content,width,size,leading,font,color)

    def _card_layout(self, card, top):
        """One source of truth for height measurement AND actual drawn baselines.

        No section is allowed to use a fixed y independent of the content above.
        The figure owns a separate reserved right-side column.
        """
        has_fig=bool(card.get('figure'))
        y=top+39  # enough room below 19pt title strip for 8pt heading ascenders
        layout=[]
        for si,sec in enumerate(card['sections']):
            title_y=y
            y+=17.5 # heading and body can never share the same line box
            bullets=[]
            width=238 if has_fig and si==0 else (238 if has_fig else 380)
            for bullet in sec['bullets']:
                bullet_baseline=y
                height=self._h(bullet,width,7.65,12.35)
                bullets.append((bullet_baseline,bullet,width,height))
                y+=height+3.2
            layout.append((si+1,title_y,sec,bullets))
            y+=8.0
        content_end=y+6
        figure_bottom=(top+123 if has_fig else top)
        panel_bottom=max(content_end, figure_bottom+12)
        return layout, panel_bottom-top

    def measure_card(self,card):
        return self._card_layout(card,0)[1]

    def _work_height(self,worked):
        if not worked:return 0
        lines=worked.get('lines') or []
        return 15+sum(self._h(item,350,7.65,11.6)+2 for item in lines)+7

    def _concept_extras(self,card,top,notes=None,draw=False,number=1):
        """Single measure/draw path; positions are identical for variable-length JSON."""
        x,w=58,418
        y=top+8
        if notes:
            if draw:
                self.fill(x,y+1,44,15,'m_orange',2)
                self.tx(x+12,y+12,'마플해설','b',7.1,'white')
                bottom=self._paragraph(x+54,y+11,notes,334,7.45,11.2)
            else:
                bottom=y+11+self._h(notes,334,7.45,11.2)
            y=max(y+16,bottom+5)+8
        worked=card.get('worked') or {}
        questions=worked.get('exercise_questions') or []
        if questions:
            if draw:
                self.fill(x,y+1,36,13,'m_teal',2)
                self.tx(x+8,y+11,'보기','sb',7.1,'white')
                self.tx(x+43,y+10.6,str(worked.get('example_no','01')),'b',7.4,'m_teal')
            pos=y+9.9
            for q in questions:
                pos=(self._paragraph(x+60,pos,q,w-68,7.55,11.3) if draw else pos+self._h(q,w-68,7.55,11.3))+2
            y=max(y+16,pos+5)+5
        lines=worked.get('lines') or []
        if lines:
            if draw:
                self.fill(x,y+1,36,13,'white',2,'m_teal',.5)
                self.tx(x+10,y+11,'풀이','sb',7.05,'m_teal')
            pos=y+10.0
            for item in lines:
                pos=(self._paragraph(x+46,pos,item,w-54,7.5,11.15) if draw else pos+self._h(item,w-54,7.5,11.15))+2
            y=max(y+16,pos+4)
        return y+4

    def _card_extra_height(self,card,note):
        return self._concept_extras(card,0,note,False)

    def concept_card(self,card,number,top,notes=None):
        plan,panel_h=self._card_layout(card,top)
        x=58;w=418
        self.fill(x,top,w,panel_h,'white',6,'m_teal',.9)
        self.fill(x,top,w,19,'m_teal',6)
        self.fill(x,top+13,w,6,'m_teal')
        self.fill(x+6,top+1,35,23,'white',4)
        self.tx(x+11,top+16,f'{number:02d}','sb',16.5,'m_orange')
        self.tx(x+49,top+14,card['title'],'b',8.65,'white',max_width=w-60)
        bg_top=top+29
        self.fill(x+9,bg_top,w-18,panel_h-39,'#F7F8F7',2)
        if card.get('figure'):
            self.figure(card['figure'],x+w-140,top+47,125,70)
        for section_number,title_y,sec,bullets in plan:
            self.tx(x+13,title_y,f'({section_number}) {sec["name"]}','b',7.85,'m_text')
            for yy,bullet,width,height in bullets:
                drawn_end=self._paragraph(x+17,yy,bullet,width,7.65,12.35)
                if abs(drawn_end-(yy+height))>1:
                    self.errors.append({'type':'concept_measure_draw_mismatch','page':len(self.pages),'concept':number})
                if drawn_end>top+panel_h-4:
                    self.errors.append({'type':'concept_text_outside_panel','page':len(self.pages),'concept':number})
        bottom=self._concept_extras(card,top+panel_h,notes,draw=True,number=number)
        self.layout_metrics['concept_cards'].append({'page':len(self.pages),'x':x,'y':round(top,1),'width':w,'panel_height':round(panel_h,1),'end':round(bottom,1)})
        return bottom-top

    def _split_card(self,card,max_height=505):
        """Preserve every section/bullet; split huge concept cards at bullet boundaries."""
        if self.measure_card(card)+self._card_extra_height(card,'')<=max_height:return [card]
        # Split a very long card into source-ordered continuation cards.
        fragments=[];current={'title':card['title'],'sections':[]}
        def commit():
            nonlocal current
            if not current['sections']:return
            fragments.append(current)
            current={'title':card['title'],'sections':[]}
        for sec in card['sections']:
            for bi,bullet in enumerate(sec['bullets']):
                name=sec['name']
                if current['sections'] and current['sections'][-1]['name']==name:
                    current['sections'][-1]['bullets'].append(bullet)
                else:current['sections'].append({'name':name,'bullets':[bullet]})
                candidate=dict(current)
                if not fragments and card.get('figure'):candidate['figure']=card['figure']
                if self.measure_card(candidate)>max_height and sum(len(x['bullets']) for x in current['sections'])>1:
                    current['sections'][-1]['bullets'].pop()
                    if not current['sections'][-1]['bullets']:current['sections'].pop()
                    commit()
                    current['sections'].append({'name':name,'bullets':[bullet]})
        commit()
        if fragments:
            if card.get('figure'):fragments[0]['figure']=card['figure']
            if card.get('worked'):fragments[-1]['worked']=card['worked']
        return fragments

    def _concept_cards(self,t,n):
        """Deterministically pack cards using the same measured boxes as drawing.

        An intact card remains on the current page iff its measured panel,
        note, worked example and question/solution all fit above the footer.
        This decision uses no AI judgement, fixed card-count, or guesswork.
        """
        cards=t['concept_cards']
        if not cards:return
        notes=t.get('notes') or []
        self.page('C_concept',t['title']);self.chapter_head(t,n)
        cy=87
        max_bottom=676  # footer line y=686; retain >=10pt clearance
        gap=8           # previous 12pt gap needlessly pushed small cards away
        for i,c in enumerate(cards):
            frags=self._split_card(c,max_height=490)
            ntext=notes[i] if i<len(notes) else None
            nbody=(ntext.get('body','') if isinstance(ntext,dict) else str(ntext or ''))
            for j,frag in enumerate(frags):
                note=nbody if j==len(frags)-1 else ''
                exact_h=self.measure_card(frag)+self._card_extra_height(frag,note)
                # Do not move an individual card on heuristic percentage / AI advice.
                # The exact same methods determine where drawing ends.
                if cy+exact_h>max_bottom and cy>100:
                    self.layout_metrics.setdefault('concept_page_breaks',[]).append({
                        'after_page':len(self.pages),'next_card':i+1,
                        'reason':'measured_height_exceeds_available_space',
                        'needed_pt':round(exact_h,2),'remaining_pt':round(max_bottom-cy,2)})
                    self.frame_footer();self.end()
                    self.page('C_concept_continue',t['title'])
                    self.chapter_head(t,n,continuation=True);cy=56
                if cy+exact_h>max_bottom:
                    self.errors.append({'type':'mapl_oversized_concept_card',
                        'page':len(self.pages),'card':i+1,'needed':round(exact_h,1),
                        'available':round(max_bottom-cy,1)})
                drawn_h=self.concept_card(frag,i+1,cy,note)
                if abs(drawn_h-exact_h)>1:
                    self.errors.append({'type':'concept_packing_measure_draw_mismatch',
                                        'page':len(self.pages),'card':i+1,
                                        'measured':round(exact_h,2),'drawn':round(drawn_h,2)})
                self.layout_metrics.setdefault('concept_packing',[]).append({
                    'page':len(self.pages),'card':i+1,'part':j+1,
                    'top':round(cy,2),'measured_height':round(exact_h,2),
                    'bottom':round(cy+drawn_h,2),'page_limit':max_bottom})
                cy+=drawn_h+gap
        self.frame_footer();self.end()

    def _core_strip(self,x,y,w,t):
        note=t.get('mapl_core')
        if not note:
            sections=t['concept_cards'][0]['sections']
            note=sections[0]['bullets'][0] if sections and sections[0]['bullets'] else '핵심 개념과 조건을 확인합니다.'
        note_width=w-104
        nh=self._h(note,note_width,7.65,12.0)
        h=max(35,20+nh+7)
        self.fill(x,y,w,h,'#F8FAF9',8)
        self.line(x,y,x+w,y,'m_blue',1.2)
        self.fill(x+6,y+7,75,14,'m_blue',7)
        self.tx(x+15,y+17,'MAPL CORE  ▶','sb',6.7,'white')
        drawn=self._paragraph(x+90,y+18,note,note_width,7.65,12,color='m_orange')
        if drawn>y+h-2:
            self.errors.append({'type':'core_text_outside_box','page':len(self.pages)})
        return h

    def _section_tag(self,x,y,label):
        size=7.4
        text_w=pdfmetrics.stringWidth(str(label), self.fonts['b'][0], size)
        box_w=max(60, text_w+24)
        self.fill(x,y-8,box_w,14,'white',5,'m_rule')
        self.tx(x+box_w/2,y+0.2,label,'b',size,'m_blue',align='center')
        return box_w

    def _select_category(self,q,j):
        label=q.get('category','')
        if label:return label
        lev=str(q.get('level','')).lower()
        if lev in ('발전','심화','상','hard'):return '발전문제'
        if lev in ('변형','중','normal'):return '변형문제'
        if j==0:return '확인문제'
        return '변형문제' if j%3 else '발전문제'

    def _option_text(self,i,opt):
        if isinstance(opt,dict):
            if 'latex' in opt:
                return CIRCLES[i%10]+r' \('+opt['latex']+r'\)'
            opt=opt.get('text','')
        return CIRCLES[i%10]+' '+str(opt)

    def _choices_layout(self,options,avail,size=8.0):
        if not options:return ('none',0)
        if any(isinstance(v,dict) and 'latex' in v or (isinstance(v,str) and ('\\(' in v or '$' in v)) for v in options):
            return ('vertical',len(options)*15)
        widths=[pdfmetrics.stringWidth(self._option_text(i,v),self.fonts['r'][0],size)+14 for i,v in enumerate(options)]
        if sum(widths)<=avail:return ('inline',15)
        if max(widths)<avail/2-10:return ('two',math.ceil(len(options)/2)*15)
        return ('vertical',len(options)*15)

    def _options_height(self,opts,avail,size):
        if not opts:return 0
        mode,_=self._choices_layout(opts,avail,size)
        if mode=='inline':return 16
        if mode=='two':
            col=avail/2-6
            return sum(max(self._h(self._option_text(j,opts[j]),col,size,12) for j in range(i,min(i+2,len(opts))))+3 for i in range(0,len(opts),2))
        return sum(self._h(self._option_text(i,v),avail-8,size,12)+3 for i,v in enumerate(opts))

    def _exercise_height(self,q):
        figure=q.get('figure');bodyw=225 if figure else 331
        bodyh=self._h(q['s'],bodyw,8.28,12.55)
        opts=q.get('ch') or []
        optionh=self._options_height(opts,326,7.9)
        return max(48,bodyh+optionh+(5 if opts else 0)+17,94 if figure else 0)+7

    def _draw_options(self,opts,x,y,avail=344,size=7.9):
        mode,_=self._choices_layout(opts,avail,size)
        if mode=='inline':
            widths=[max(34,pdfmetrics.stringWidth(self._option_text(i,v),self.fonts['r'][0],size)+10) for i,v in enumerate(opts)]
            xx=x
            for i,opt in enumerate(opts):
                self.rich(xx,y,self._option_text(i,opt),widths[i],size,12)
                xx+=widths[i]
            return y+16
        if mode=='two':
            col=avail/2;pos=y
            for i in range(0,len(opts),2):
                row_h=0
                for j in range(i,min(i+2,len(opts))):
                    end=self.rich(x+(j-i)*col,pos,self._option_text(j,opts[j]),col-6,size,12)
                    row_h=max(row_h,end-pos)
                pos+=row_h+3
            return pos
        pos=y
        for i,opt in enumerate(opts):
            pos=self.rich(x,pos,self._option_text(i,opt),avail-8,size,12)+3
        return pos

    def figure(self,figure,x,y,w=105,h=80):
        """Vector diagram for line/coordinate-plane/triangle/graph specifications."""
        if not figure:return
        typ=figure.get('type')
        self.c.saveState()
        if typ in ('number_line','coordinate_plane','plot'):
            cx=x+w*.45;cy=y+h*.53
            xmin,xmax=figure.get('x_range',[-4,4]);ymin,ymax=figure.get('y_range',[-3,3])
            if xmax==xmin or ymax==ymin:
                self.c.restoreState();return
            def pt(a,b):return (x+(a-xmin)/(xmax-xmin)*w, y+h-(b-ymin)/(ymax-ymin)*h)
            if typ=='number_line':
                oy=y+h*.53
                self.line(x+4,oy,x+w-4,oy,'#444444',.65)
            else:
                self.line(*pt(xmin,0),*pt(xmax,0),'#555555',.55)
                self.line(*pt(0,ymin),*pt(0,ymax),'#555555',.55)
                self.tx(*pt(0,0),'O','r',5.4,'m_gray')
            # Optional distinct graph branches: curves[] makes one-sided limits,
            # removable holes and jump discontinuities visually explicit.
            # Legacy curve: [[x,y], ...] remains supported unchanged.
            curves=figure.get('curves') or []
            if not curves and figure.get('curve'):
                curves=[{'points':figure['curve']}]
            for branch in curves:
                coords2=branch.get('points',[])
                if len(coords2)<2:continue
                color=branch.get('color','#008CCC')
                self.c.setStrokeColor(HexColor(color));self.c.setLineWidth(branch.get('width',1.1))
                path=self.c.beginPath()
                for i,coord in enumerate(coords2):
                    px,py=pt(float(coord[0]),float(coord[1]))
                    if i==0:path.moveTo(px,H-py)
                    else:path.lineTo(px,H-py)
                self.c.drawPath(path)
            for p in figure.get('points',[]):
                xx,yy=pt(p['x'],p.get('y',0))
                point_color=p.get('color','#222222')
                radius=float(p.get('radius',2.5))
                if p.get('open',False):
                    self.c.setFillColor(HexColor('#FFFFFF'))
                    self.c.setStrokeColor(HexColor(point_color))
                    self.c.setLineWidth(.85)
                    self.c.circle(xx,H-yy,radius,stroke=1,fill=1)
                else:self.fill(xx-radius,yy-radius,radius*2,radius*2,point_color,rad=radius)
                if p.get('label'):
                    self.tx(xx+float(p.get('dx',3)),yy+float(p.get('dy',-4)),p['label'],'r',5.9,'m_text')
        elif typ=='triangle':
            p=figure.get('points',[{'x':0,'y':0,'label':'A'},{'x':1,'y':0,'label':'B'},{'x':.5,'y':.9,'label':'C'}])
            pts=[(x+18+float(v['x'])*(w-35),y+h-12-float(v['y'])*(h-25)) for v in p]
            for i in range(len(pts)):
                a,b=pts[i],pts[(i+1)%len(pts)]
                self.line(a[0],a[1],b[0],b[1],'#222222',.75)
            for (px,py),v in zip(pts,p):
                self.fill(px-1.2,py-1.2,2.4,2.4,'#222222',2)
                self.tx(px+2,py-2,v.get('label',''),'r',6.7,'m_text')
        self.c.restoreState()

    def _exercise_question(self,no,q,x,y,index):
        # align category label, number, and first text line on a cleaner common baseline
        label=self._select_category(q,index)
        labcol='m_leaf' if label=='확인문제' else ('m_blue' if label=='변형문제' else 'm_pink')
        self.tx(x,y-0.2,label,'b',7.95,labcol)
        self.tx(x+47,y+0.4,f'{no:04d}','sb',12.25,'m_text')
        fig=q.get('figure');bodyx=x+89;bodyw=342 if not fig else 236
        yy=self._paragraph(bodyx,y-0.8,q['s'],bodyw,8.28,12.55)
        if fig:self.figure(fig,x+338,y-9,90,74)
        opts=q.get('ch') or []
        if opts:yy=self._draw_options(opts,bodyx,yy+5,326)
        return max(y+self._exercise_height(q)-16,yy+7)


    @staticmethod
    def _number_once(q,index):
        """Respect pre-numbered legacy JSON and generate exactly one prefix."""
        if isinstance(q,dict):
            value=q.get('text',q.get('latex',''))
        else:value=str(q)
        stripped=re.sub(r'^\s*(?:\(\s*\d+\s*\)|[①②③④⑤⑥⑦⑧⑨⑩]|\d+[.)])\s*','',value,count=1)
        return f'({index}) {stripped}'

    def _concept_question_block(self,x,y,w,card):
        worked=card.get('worked') or {}
        qs=worked.get('exercise_questions') or []
        if not qs:
            return 0
        pos=y
        for i,q in enumerate(qs,1):
            line=self._number_once(q,i)
            pos=self._paragraph(x,pos,line,w,7.95,11.8)+3
        return pos-y

    def _worked_panel(self,x,y,w,card):
        worked=card.get('worked') or {}
        lines=worked.get('lines') or [card['sections'][0]['bullets'][0]]
        text_x=x+88
        text_w=w-100
        text_leading=11.5
        measured=sum(self._h(line,text_w,7.55,text_leading)+2 for line in lines)
        h=max(22,12+measured+4)
        # transparent/open worked-solution block: label plus content only
        tag_w=self._section_tag(x+2,y+16,'개념익힘풀이')
        pos=y+16
        for line in lines:
            pos=self._paragraph(text_x,pos,line,text_w,7.55,text_leading)+2
        self.layout_metrics.setdefault('worked_boxes',[]).append({
            'page':len(self.pages),'x':x,'y':round(y,1),'w':w,'h':round(h,1),
            'content_x':text_x,'content_bottom':round(pos,1)})
        return max(h, pos-y)

    def _exercise_pages(self,t,n,items):
        remaining=list(items);p=0
        dense_answer_strip=any(any(k!='text' for k,_ in segments(q.get('a',''))) for _,q in items)
        while remaining or p==0:
            self.page('C_exercise',t['title']);self.compact_heading(t,n)
            first=(p==0)
            cy=80
            if first:
                self.tx(118,78,'다음 물음에 답하시오.','b',8.3,'m_text')
                cy=96
                # place concept exercise questions first
                qh=self._concept_question_block(120,cy,350,t['concept_cards'][0])
                if qh:
                    cy+=qh+10
                coreh=self._core_strip(63,cy,425,t)
                cy+=coreh+10
                workedh=self._worked_panel(63,cy,425,t['concept_cards'][0])
                cy=cy+workedh+20
            else:
                self.tx(65,90,'개념 확인 · 변형 · 발전 문제','b',8.6,'m_gray');cy=111
            answers=[];did=0
            while remaining:
                no,q=remaining[0]
                needed=self._exercise_height(q)+15
                if cy+needed>(633 if dense_answer_strip else 653):
                    if did==0:
                        self.errors.append({'type':'mapl_oversized_exercise','page':len(self.pages),'id':no,'needed':round(needed,1)})
                        raise BuildError(f'Exercise too tall for one page: {no}')
                    break
                end=self._exercise_question(no,q,62,cy+13,p+did)
                answers.append((no,q['a']));remaining.pop(0);did+=1
                cy=max(cy+needed,end+7)
                self.layout_metrics['exercise_blocks'].append({'page':len(self.pages),'number':no,'top':round(cy-needed,1),'bottom':round(cy,1)})
            self.frame_footer(kind='exercise',answers=answers);self.end();p+=1

    def _type_content(self,t,group,w):
        core=group.get('intro') or (t.get('notes') or [{'body':'개념의 조건을 정리합니다.'}])[0]
        if isinstance(core,dict):core=core.get('body','핵심 성질을 확인합니다.')
        key=group.get('key_points') or []
        if not key:key=[b for c in t['concept_cards'] for section in c['sections'] for b in section['bullets'][:1]][:2]
        has_fig=bool(group.get('figure'))
        text_w=(w-22) if not has_fig else (w-122)
        pos=45+self._h(core,text_w,7.45,10.4)
        if key:pos+=11
        for item in key:pos+=self._h('• '+str(item),text_w,7.05,9.8)+2
        height=max(pos+5,118 if has_fig else 0)
        return core,key,text_w,height

    def _type_box(self,x,y,w,number,title,t,group):
        core,key,intro_w,h=self._type_content(t,group,w)
        # Never cap measured height: clipping a tall type box is worse than an explicit error.
        self.fill(x,y,w,h,'#F2F9F8',4)
        self.fill(x,y,w,21,'m_teal',4)
        self.fill(x,y+16,w,5,'m_teal')
        self.fill(x,y,46,23,'#E65D75',4)
        self.tx(x+4,y+15.2,'유형','sb',6.9,'white')
        self.tx(x+24,y+15.4,f'{number:02d}','sb',12.7,'white')
        self.tx(x+53,y+14.6,title,'b',8.25,'white',max_width=w-57)
        has_fig=bool(group.get('figure'))
        fig_x=x+w-72 if has_fig else None
        fig_y=y+40 if has_fig else None
        fig_w=60 if has_fig else 0
        fig_h=58 if has_fig else 0
        text_right=(fig_x-14) if has_fig else (x+w-10)
        bullet_w=max(40, text_right-(x+13))
        self.tx(x+10,y+33.5,'핵심 개념','b',7.75,'m_text')
        pos=self._paragraph(x+11,y+45,core,intro_w,7.45,10.4)
        if key:
            rule_end=text_right if has_fig else x+w-10
            self.line(x+10,pos+2,rule_end,pos+2,'m_rule',.5);pos+=11
        for item in key:
            pos=self._paragraph(x+13,pos,'• '+str(item),bullet_w,7.05,9.8)+2
        if has_fig:
            self.figure(group['figure'],fig_x,fig_y,fig_w,fig_h)
        if pos>y+h-4:self.errors.append({'type':'type_box_text_overflow','page':len(self.pages),'type':number})
        self.layout_metrics['type_blocks'].append({'page':len(self.pages),'kind':'intro','type':number,'top':round(y,1),'height':round(h,1)})
        return h

    def _type_qheight(self,q):
        fig=q.get('figure');bodyw=122 if fig else 199
        bodyh=self._h(q['s'],bodyw,8.0,11.8)
        opts=q.get('ch') or []
        # When a figure exists, reserve the area below the figure for options so
        # that the same graph does not visually intrude into the choice row.
        if fig:
            question_bottom=18+bodyh
            options_top=max(question_bottom+6, 15+70+6)
            opth=self._options_height(opts,122,7.3) if opts else 0
            return max(52, options_top+opth+12, 94)
        opth=self._options_height(opts,201,7.3)
        return max(52,18+bodyh+opth+(6 if opts else 0)+12)

    def _draw_type_q(self,x,y,w,no,q):
        level=str(q.get('level','')).lower()
        lv='BASIC' if level in ('기본','basic','하') else 'TOUGH' if level in ('심화','hard','상') else 'NORMAL'
        self.tx(x,y,f'{no:04d}','sb',14.5,'m_teal')
        self.tx(x+w,y-2,lv,'sb',6,'m_orange',align='right')
        fig=q.get('figure')
        ww=w-12 if not fig else w-89
        ey=self._paragraph(x+1,y+18,q['s'],ww,8.0,11.8)
        if fig:
            fig_x=x+w-84; fig_y=y+15; fig_w=79; fig_h=70
            self.figure(fig,fig_x,fig_y,fig_w,fig_h)
        if q.get('ch'):
            # For figure questions, start options below the figure and keep them
            # within the text column, so the graph never duplicates/intrudes.
            if fig:
                options_y=max(ey+6, y+15+70+6)
                options_w=w-89
                ey=self._draw_options(q['ch'],x+2,options_y,options_w,7.3)
            else:
                ey=self._draw_options(q['ch'],x+2,ey+6,w-10,7.3)
        self.layout_metrics['type_blocks'].append({'page':len(self.pages),'kind':'question','number':no,'top':round(y,1),'bottom':round(max(y+self._type_qheight(q),ey+9),1)})
        return max(y+self._type_qheight(q),ey+9)

    def _type_pages(self,t,n,items):
        if not items:return
        raw_groups=t.get('advanced_types') or []
        if raw_groups:
            groups=[];consumed=set()
            for g in raw_groups:
                inds=g.get('question_indices',[])
                selected=[items[i] for i in inds if 0<=i<len(items)]
                consumed.update(i for i in inds if 0<=i<len(items))
                if selected:
                    # A graph belonging to a numbered question must be drawn
                    # with that question, not repeated in the type overview.
                    # Keep a genuinely different, overview-only graph intact.
                    overview=dict(g)
                    if overview.get('figure') and any(
                        q.get('figure') == overview['figure'] for _,q in selected
                    ):
                        overview.pop('figure')
                    groups.append((overview,selected))
            extra=[v for i,v in enumerate(items) if i not in consumed]
            if extra:groups.append(({'title':'기타 연습'},extra))
        else:
            names=t.get('advanced_headers') or [c['title'] for c in t['concept_cards']]
            groups=[({'title':names[(i//3)%len(names)]},items[i:i+3]) for i in range(0,len(items),3)]
        pending=[{'number':i+1,'group':g,'questions':list(qs),'fresh':True} for i,(g,qs) in enumerate(groups)]
        page_idx=0
        while pending:
            self.page('T_first' if page_idx==0 else 'T_continue',t['title'])
            self.line(270,112 if page_idx==0 else 39,270,663,'#CCD5D3',.5)
            if page_idx==0:
                self.fill(50,26,438,75,'m_teal',17)
                self.tx(72,82,f'{n:02d}','sb',42,'#FFDE00')
                self.tx(171,51,'STEP  내신정복 기출유형','r',7.7,'white')
                self.tx(171,77,t['title'],'sb',16.6,'white',max_width=296)
                y_start=119
            else:
                self.tx(52,31,'MAPL  SYNERGY  ·  유형별 기출 연습','sb',8,'m_teal')
                self.tx(486,31,t['title'],'b',7.8,'m_gray',align='right')
                y_start=51
            self.side_index(n)
            progressed=0
            for x in (52,277):
                y=y_start
                while pending:
                    cur=pending[0]
                    number,g,qs=cur['number'],cur['group'],cur['questions']
                    if cur['fresh']:
                        core=g.get('intro') or (t.get('notes') or [{'body':'개념의 조건을 정리합니다.'}])[0]
                        if isinstance(core,dict):core=core.get('body','')
                        approx_h=self._type_content(t,g,211)[3]
                        if y+approx_h+self._type_qheight(qs[0][1])+18>651:
                            break
                        y+=self._type_box(x,y,211,number,g.get('title','핵심 유형'),t,g)+18
                        cur['fresh']=False
                    elif y==y_start:
                        # do not repeat the type header box on continuation columns/pages
                        pass
                    while qs and y+self._type_qheight(qs[0][1])<651:
                        no,q=qs.pop(0)
                        y=self._draw_type_q(x,y,211,no,q)+8
                        progressed+=1
                    if qs:break
                    pending.pop(0)
                    if not pending or y>550:break
                    y+=7
            self.frame_footer(kind='type');self.end();page_idx+=1
            if progressed==0 and pending:
                raise BuildError(f'Type group cannot fit in a column: {pending[0]["group"].get("title")}')

    def _special_proof_height(self,q):
        """One proof per page: question, genuine handwriting room, complete proof."""
        question_h=self._h(q['s'],390,8.65,13.65)
        proof_h=self._h(q['e'],390,8.3,13.0)
        # Reserve 8–9cm for handwritten work, not a token blank line.
        answer_space=max(225,min(255,505-(question_h+proof_h+74)))
        return 35+question_h+12+answer_space+8+24+proof_h+16

    def _draw_special_proof(self,q,number,top):
        x=59;w=422
        question_h=self._h(q['s'],390,8.65,13.65)
        proof_h=self._h(q['e'],390,8.3,13.0)
        answer_space=max(225,min(255,505-(question_h+proof_h+74)))
        height=self._special_proof_height(q)
        self.fill(x,top,w,21,'m_orange',5)
        self.tx(x+12,top+15,f'증명 연습 {number:02d}','b',9.4,'white')
        self.fill(x,top+21,w,height-21,'white',4,'m_rule',0.7)
        q_end=self._paragraph(x+13,top+35,q['s'],390,8.65,13.65)
        # Deliberately blank handwriting area. No answer, hints or source IDs.
        proof_label_y=q_end+12+answer_space+8
        self.line(x+12,proof_label_y-10,x+w-12,proof_label_y-10,'m_rule',0.8)
        self.tx(x+13,proof_label_y,'증명 해설','b',8.7,'m_teal')
        pos=self._paragraph(x+13,proof_label_y+18,q['e'],390,8.3,13.0)
        if pos>top+height-5:
            self.errors.append({'type':'special_proof_overflow','page':len(self.pages),
                                'number':number,'drawn_bottom':round(pos,1),
                                'container_bottom':round(top+height,1)})
        self.layout_metrics.setdefault('special_proof_boxes',[]).append({
            'page':len(self.pages),'number':number,'top':round(top,1),
            'bottom':round(top+height,1),'blank_space_pt':round(answer_space,1)})
        return height

    def _special_lesson(self,t,n):
        special=t.get('special_lecture')
        if not isinstance(special,dict) or special.get('enabled') is False:return
        proofs=special.get('proof_questions') or []
        if not proofs:return
        for j,q in enumerate(proofs,1):
            if j==1:
                self.page('C_special',t['title']);self.fill(0,0,W,70,'m_orange')
                self.fill(51,0,84,73,'#FFDA00',10)
                self.tx(59,52,'마플특강','sb',14,'m_teal')
                self.tx(153,51,f'{n:02d}','sb',27,'white')
                self.tx(207,48,'증명 연습','sb',16,'white',max_width=280)
                self.side_index(n)
                y=102
            else:
                self.page('C_special_continue',t['title'])
                self.compact_heading(t,n,'마플특강');y=95
            need=self._special_proof_height(q)
            if y+need>660:
                raise BuildError(f'증명 연습 {j}: 해설이 페이지 영역을 넘습니다. 해설을 수학적으로 의미 있는 단계로 나누세요.')
            self._draw_special_proof(q,j,y)
            self.frame_footer();self.end()

    def concept(self,t,n):
        self._concept_cards(t,n)

    def basic(self,t,n,items):
        self._exercise_pages(t,n,items)

    def advanced(self,t,n,subset,bpage):
        # Override make() to use the full semantic list once, not old 8-item chunks.
        self._type_pages(t,n,subset)

    def validate_model(self):
        # Preserve all original source/answer/numeric requirements, but do not
        # require 2 cards or 4 notes for this flexible visual page format.
        ts=self.data.get('themes',[])
        if not ts:raise BuildError('No themes')
        for i,t in enumerate(ts,1):
            if not t.get('concept_cards'):
                self.errors.append({'type':'missing_concept_cards','theme':i})
            for j,card in enumerate(t.get('concept_cards',[]),1):
                if not card.get('sections'):
                    self.errors.append({'type':'missing_sections','theme':i,'card':j})
            for typ in ('basic','advanced'):
                for q in t.get(typ,[]):
                    if not all(str(q.get(k,'')).strip() for k in ('s','a','e')):
                        self.errors.append({'type':'missing_answer_or_explanation','theme':i,'family':typ})
            special=t.get('special_lecture')
            if isinstance(special,dict) and special.get('sections') and not special.get('trigger_reason'):
                self.errors.append({'type':'unjustified_special_lecture','theme':i})

    def _make_cover(self):
        """Data-driven cover. No course-specific insurance/actuarial copy.

        meta.cover fields override the typographic decorations independently of
        the interior layout. Without explicit fields, use the JSON's own title
        as the repeated background motif, so any subject works automatically.
        """
        meta=self.data['meta']
        design=meta.get('cover') or {}
        buf=io.BytesIO();c=pdf_canvas.Canvas(buf,pagesize=(W,H))
        pink='#F50085';yellow='#EBFF00';white='#FFFFFF';ink='#29252B'
        cover_title=str(meta.get('cover_title') or meta['title'])
        background=str(design.get('background_text') or meta.get('subject') or cover_title)
        eyebrow=str(design.get('eyebrow') or 'MATHEMATICS  ·  WORKBOOK')
        unit_label=str(design.get('unit_label') or 'UNIT')
        unit_caption=str(design.get('unit_caption') or 'CONCEPT · PRACTICE · APPLICATION')
        footer_caption=str(design.get('footer_caption') or 'LECTURE-BASED MATHEMATICS WORKBOOK')

        def fitted(text,x,y,max_width,size,font='sb',min_size=6):
            """Draw a single line within its allotted width without silent clipping."""
            label=str(text)
            family=self.fonts[font][0]
            pt=size
            while pt>min_size and pdfmetrics.stringWidth(label,family,pt)>max_width:
                pt-=0.5
            if pdfmetrics.stringWidth(label,family,pt)>max_width:
                while label and pdfmetrics.stringWidth(label+'…',family,pt)>max_width:
                    label=label[:-1]
                label+='…'
            c.setFont(family,pt);c.drawString(x,y,label)

        c.setFillColor(HexColor(pink));c.rect(0,155,W,H-155,fill=1,stroke=0)
        for j in range(7):
            c.setFillColor(HexColor('#FC53AA' if j%2 else '#E00074'))
            fitted(background,16,H-44-j*57,506,25,min_size=14)
        c.setFillColor(HexColor(yellow))
        fitted(eyebrow,40,H-56,470,16,min_size=9)
        c.setFillColor(HexColor(pink));c.rect(0,386,W,88,fill=1,stroke=0)
        c.setFillColor(HexColor(white));c.setFont(self.fonts['sb'][0],38)
        lines=self.wrap(cover_title,'sb',38,455)
        top=H-312
        for line in lines[:3]:
            fitted(line,39,top,465,38,min_size=22);top-=50
        code=str(meta.get('chapter_code','01'))
        c.setFillColor(HexColor(yellow))
        family=self.fonts['sb'][0]
        code_font=min(125,125*max(0.45, min(1.,100/max(1, len(code)*32))))
        while pdfmetrics.stringWidth(code,family,code_font)>460 and code_font>38:code_font-=3
        c.setFont(family,code_font);c.drawRightString(505,171,code)
        c.setFillColor(HexColor(white));c.rect(0,0,W,155,stroke=0,fill=1)
        c.setFillColor(HexColor(pink))
        fitted(f'{unit_label}  {code}  |  {unit_caption}',40,130,460,10,min_size=7)
        c.setFillColor(HexColor(ink));c.setFont(self.fonts['sb'][0],19)
        main_title=meta.get('short_chapter') or meta['title']
        for line in self.wrap(main_title,'sb',19,460)[:2]:
            fitted(line,40,100,458,19,min_size=12)
        c.setFont(self.fonts['r'][0],9)
        all_themes=self.data.get('themes',[])
        if 1<len(all_themes)<=8:
            c.setFillColor(HexColor(pink))
            fitted(str(design.get('contents_label') or '목차  |  학습 테마'),41,80,450,8.5,min_size=7)
            c.setFillColor(HexColor(ink));c.setFont(self.fonts['r'][0],7.4)
            for i,t in enumerate(all_themes):
                xx=41 if i<4 else 276
                yy=65-(i%4)*11
                fitted(f'{i+1:02d}  {t["title"]}',xx,yy,215,7.4,'r',6.5)
            c.setStrokeColor(HexColor('#EEEEEE'));c.line(39,17,501,17)
            c.setFillColor(HexColor(ink));fitted(footer_caption,41,6,458,6.5,'r',6)
        elif len(all_themes)>8:
            c.drawString(41,72,'전체 테마 목차는 다음 페이지에 수록되어 있습니다.')
            c.setStrokeColor(HexColor('#EEEEEE'));c.line(39,42,501,42)
            fitted(footer_caption,41,23,458,7.5,'r',6)
        else:
            c.drawString(41,72,'개념다지기   ·   마플개념익힘   ·   유형쪼개기   ·   정답과 상세 해설')
            c.setStrokeColor(HexColor('#EEEEEE'));c.line(39,42,501,42)
            fitted(footer_caption,41,23,458,7.5,'r',6)
        c.save();return buf.getvalue()

    def _make_contents(self):
        """Only substantial (>8-theme) contents get their own page."""
        buf=io.BytesIO();c=pdf_canvas.Canvas(buf,pagesize=(W,H))
        c.setFillColor(HexColor('#00AB9C'));c.setFont(self.fonts['sb'][0],26)
        c.drawString(45,H-60,'목차')
        c.setStrokeColor(HexColor('#A8D7D2'));c.line(45,H-79,496,H-79)
        c.setFillColor(HexColor('#606060'));c.setFont(self.fonts['r'][0],10)
        c.drawString(47,H-104,'학습 주제별 개념과 문제 · 정답 및 해설')
        themes=self.data.get('themes',[])
        rows=(len(themes)+1)//2
        if rows>23:raise BuildError('More than 46 themes: divide contents into volume files.')
        for i,t in enumerate(themes):
            col=i//rows;row=i%rows
            x=48+col*236;y=H-143-row*(510/max(1,rows-1) if rows>1 else 21)
            c.setFillColor(HexColor('#00AB9C'));c.setFont(self.fonts['sb'][0],12)
            c.drawString(x,y,f'{i+1:02d}')
            c.setFillColor(HexColor('#272727'));c.setFont(self.fonts['r'][0],9)
            name=t['title'];name=name if len(name)<24 else name[:22]+'…'
            c.drawString(x+32,y+1,name)
        c.setStrokeColor(HexColor('#C5E5E6'));c.line(45,53,496,53)
        c.setFont(self.fonts['r'][0],7.5);c.setFillColor(HexColor('#65615E'))
        c.drawString(48,35,'각 테마: 개념다지기  ·  마플개념익힘  ·  유형쪼개기')
        c.save();return buf.getvalue()

    def make(self):
        # Parallel to Engine.make, without assuming 10/8 old fixed page slots.
        self.validate_model()
        for i,t in enumerate(self.data['themes'],1):
            basic=[];advanced=[]
            for q in t.get('basic',[]):
                basic.append((self.nextid,q));self.qpairs.append((self.nextid,t,q,'basic'));self.nextid+=1
            for q in t.get('advanced',[]):
                advanced.append((self.nextid,q));self.qpairs.append((self.nextid,t,q,'advanced'));self.nextid+=1
            self.concept(t,i)
            if basic:self.basic(t,i,basic)
            # Proof practice (when source contains a proof) belongs AFTER
            # 마플개념익힘, BEFORE 유형쪼개기.  Existing JSON without
            # special_lecture remains unchanged.
            self._special_lesson(t,i)
            if advanced:self.advanced(t,i,advanced,0)
        # Existing full worked solutions and source-linked formula appendix stay intact.
        # New pages have no old master PDF so are drawn as all-vector overlay pages.
        self.append_solutions()
        self.c.save()
        import fitz,json
        from engine.render_base import ROOT
        overlay=fitz.open(stream=self.buf.getvalue(),filetype='pdf')
        if len(overlay)!=len(self.pages):raise BuildError('Overlay page count mismatch')
        result=fitz.open()
        include_cover=self.data.get('meta',{}).get('include_cover',True)
        include_contents=bool(include_cover and len(self.data['themes'])>8)
        offset=int(bool(include_cover))+int(include_contents)
        if include_cover:
            with fitz.open(stream=self._make_cover(),filetype='pdf') as cover_doc:
                result.new_page(width=W,height=H)
                result[0].show_pdf_page(result[0].rect,cover_doc,0,overlay=True)
        if include_contents:
            with fitz.open(stream=self._make_contents(),filetype='pdf') as toc_doc:
                result.new_page(width=W,height=H)
                result[-1].show_pdf_page(result[-1].rect,toc_doc,0,overlay=True)
        for k,p in enumerate(self.pages):
            result.new_page(width=W,height=H)
            result[-1].show_pdf_page(result[-1].rect,overlay,k,overlay=True)
        for placement in self.math_placements:
            path,_,_,_,_,clip=self.latex.get(placement['latex'])
            with fitz.open(path) as tex_pdf:
                result[placement['page']+offset].show_pdf_page(fitz.Rect(placement['rect']),tex_pdf,0,overlay=True,keep_proportion=True,clip=fitz.Rect(clip))
        tmp=self.out.with_suffix('.tmp.pdf');result.save(tmp,garbage=4,deflate=True);result.close();tmp.replace(self.out)
        with fitz.open(self.out) as doc_check:
            for i,pg in enumerate(doc_check):
                for block in pg.get_text('dict')['blocks']:
                    if 'lines' not in block:continue
                    bx=fitz.Rect(block['bbox'])
                    if bx.x0 < -0.75 or bx.y0 < -0.75 or bx.x1 > W+0.75 or bx.y1 > H+0.75:
                        self.errors.append({'type':'rendered_text_out_of_bounds','page':i+1,'bbox':[round(v,2) for v in bx]})

        # Vector math pages are separate PDF XObjects. Check their own bounding
        # boxes and their distances from every ordinary text span on the page.
        math_by_page={}
        for placement in self.math_placements:
            page_idx=placement['page']+offset
            box=fitz.Rect(placement['rect'])
            if box.x0 < 0 or box.y0 < 0 or box.x1 > W or box.y1 > H:
                self.errors.append({'type':'math_out_of_bounds','page':page_idx+1,'formula':placement['latex'][:70]})
            math_by_page.setdefault(page_idx,[]).append((box,placement['latex']))
        for page_idx,boxes in math_by_page.items():
            for i,(a,formula) in enumerate(boxes):
                for b,_ in boxes[i+1:]:
                    overlap=a&b
                    if overlap.is_empty:continue
                    if overlap.get_area()>1.0:
                        self.errors.append({'type':'math_math_overlap','page':page_idx+1,'formula':formula[:70]})
                        break
        with fitz.open(self.out) as qa_doc:
            for page_idx,page in enumerate(qa_doc):
                if page_idx < offset:continue
                extracted=page.get_text('text')
                if re.search(r'\\(?:frac|dfrac|lambda|qquad|hat|sum|int|sqrt)\b|(?<![A-Za-z])frace(?![A-Za-z])',extracted):
                    self.errors.append({'type':'literal_latex_in_pdf','page':page_idx+1})
                if len(extracted.strip())<35:
                    self.errors.append({'type':'nearly_empty_body_page','page':page_idx+1})
                formulas=math_by_page.get(page_idx,[])
                if not formulas:continue
                spans=[span for block in page.get_text('dict')['blocks']
                       for line in block.get('lines',[])
                       for span in line.get('spans',[])
                       if span.get('text','').strip() and
                       not span.get('font','').lower().startswith(('cm','msam','msbm','lmr'))]
                for box,expr in formulas:
                    for span in spans:
                        glyph=fitz.Rect(span['bbox']);intersection=box&glyph
                        if intersection.is_empty:continue
                        area=intersection.get_area()
                        if (intersection.width>1.5 and intersection.height>1.5
                            and area>2.0 and area/min(box.get_area(),glyph.get_area())>.22):
                            self.errors.append({'type':'math_text_overlap','page':page_idx+1,
                                                'latex':expr[:60], 'text':span['text'][:40],
                                                'intersection_area':round(area,2)})
                            break
        self.layout_metrics['formula_rectangles']=[{'page':p['page']+offset+1,'rect':[round(v,2) for v in p['rect']],
                                                    'latex':p['latex'][:90]} for p in self.math_placements]
        rep={'title':self.data['meta']['title'],'pages':len(self.pages)+offset,'questions':len(self.qpairs),'themes':len(self.data['themes']),'layout_style':'mapl_reference','reference_status':'reference-inspired, not pixel-identical','errors':self.errors,'warnings':self.warnings,'pages_info':([{'role':'cover','theme':'표지','number':1}] if include_cover else [])+([{'role':'toc','theme':'목차','number':2}] if include_contents else [])+[dict(p,number=p['number']+offset) for p in self.pages],'latex_formulas':len(self.math_placements),'layout_metrics':self.layout_metrics,'font_family':self.font_source}
        self.out.with_suffix('.qa.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8')
        self.latex.close()
        if self.errors and self.strict:
            bad=self.out.with_suffix('.DRAFT_FAILED.pdf');self.out.replace(bad)
            raise BuildError(f'MAPL strict QC: {len(self.errors)} layout/content errors. Draft: {bad.name}')
        return rep
