"""PDF-level regression for Korean/math optical baseline and spaced answer cells.

Run after producing the detailed sample:
 python tests/test_rendered_alignment.py samples/상세예시_함수의극한.pdf
The test inspects the actual PDF glyph origins, not layout variables.
"""
import sys
from pathlib import Path
import fitz


def spans(page):
    return [s for b in page.get_text('dict')['blocks'] for line in b.get('lines',[])
            for s in line.get('spans',[]) if s['text'].strip()]


def get(page, exact, xmin=0, xmax=540, ymin=0, ymax=720):
    found=[s for s in spans(page) if s['text'].strip()==exact
           and xmin <= s['origin'][0] <= xmax and ymin <= s['origin'][1] <= ymax]
    if len(found)!=1:
        raise AssertionError(f'Expected one {exact!r} in {xmin,xmax,ymin,ymax}; found {len(found)}')
    return found[0]


def close_baselines(a,b,threshold=1.6):
    delta=abs(a['origin'][1]-b['origin'][1])
    assert delta <=threshold, (a['text'], b['text'], 'baseline delta', round(delta,2))
    return delta


def run(path):
    with fitz.open(path) as doc:
        assert len(doc) >= 8, 'Detailed sample PDF is expected'
        concept=doc[1]
        ex=doc[3]
        last=doc[7]
        # The example title, number and Korean following a tall fraction
        # must share their text baseline despite tall LaTeX inline content.
        example_label=get(concept,'보기',40,90,370,400)
        example_num=get(concept,'01',90,115,370,400)
        example_korean=get(concept,'(단,',160,210,370,400)
        deltas={'example_label_num':close_baselines(example_label,example_num,1),
                'example_label_korean':close_baselines(example_label,example_korean,1.7)}
        for number,text,lim in [('0001','(단,',(250,275)),
                                ('0002','함수',(365,391)),
                                ('0003','에서',(435,468))]:
            n=get(ex,number,105,152,*lim)
            korean=get(ex,text,150,310,*lim)
            deltas[number]=close_baselines(n,korean,1.6)
        # Footer text must be aligned to the '정답' label and each ID placed
        # in a dedicated wide column, rather than a collapsed space-joined run.
        for page,numbers in [(ex,('0001','0002','0003')),
                             (last,('0008','0009','0010'))]:
            label=get(page,'정답',50,85,635,685)
            ids=[get(page,num,82,480,635,685) for num in numbers]
            for item in ids:
                close_baselines(label,item,0.15)
            xs=[item['origin'][0] for item in ids]
            assert 82 <= xs[0] <= 94, ('First answer too far from label',xs[0])
            assert all(xs[i+1]-xs[i]>=100 for i in range(2)),xs
        print('PASS PDF glyph-baseline checks:',deltas)
        print('PASS same-baseline answers adjacent to label, in separated columns')


if __name__=='__main__':
    run(Path(sys.argv[1]) if len(sys.argv)>1 else Path('samples/상세예시_함수의극한.pdf'))
