"""Graph belonging to a question must not be repeated in its type header."""
import sys
from pathlib import Path
import fitz


def run(path):
    with fitz.open(path) as doc:
        # Left-hand type 01 panels on the two type pages.
        for page_idx,top,bottom in [(4,119,225),(9,119,216)]:
            page=doc[page_idx]
            panel=fitz.Rect(52,top,263,bottom)
            strokes=[]
            for drawing in page.get_drawings():
                color=drawing.get('color')
                if color is None:continue
                is_graph_blue=(abs(color[0]-0.0)<0.05 and
                               abs(color[1]-0.55)<0.06 and
                               abs(color[2]-0.8)<0.06)
                is_graph_pink=(color[0]>0.75 and color[1]<0.2 and color[2]>0.2)
                if (is_graph_blue or is_graph_pink) and drawing['rect'].intersects(panel):
                    strokes.append(drawing['rect'])
            assert not strokes, f'Page {page_idx+1}: graph still in type intro: {strokes}'
            # The exact same blue graph must remain with its numbered problem.
            q_area=fitz.Rect(160,bottom+2,263,390)
            assert any(drawing.get('color') and
                       abs(drawing['color'][0])<0.05 and
                       abs(drawing['color'][1]-0.55)<0.06 and
                       abs(drawing['color'][2]-0.8)<0.06 and
                       drawing['rect'].intersects(q_area)
                       for drawing in page.get_drawings()), f'Question graph missing on page {page_idx+1}'
    print('PASS: overview has no duplicated question graph; numbered question retains its graph')


if __name__=='__main__':
    run(Path(sys.argv[1]) if len(sys.argv)>1 else Path('samples/상세예시_함수의극한.pdf'))
