"""Regression: data-driven cover + balanced mixed Korean/LaTeX spacing.

Run: python tests/test_cover_and_math_spacing.py --font-zip /path/Pretendard.zip
No test fonts are redistributed with the project.
"""
from __future__ import annotations
import argparse, io, sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

import fitz
from reportlab.pdfbase import pdfmetrics
from engine.mapl_layout import MaplEngine


def run(font_zip=None):
    with tempfile.TemporaryDirectory() as temp:
        data={'meta':{'title':'새 과목: 대수학','source_title':'테스트','source_total_pages':1,
                      'cover_title':'선형대수','short_chapter':'행렬과 벡터'},
              'themes':[{'title':'행렬','source_pages':[1]}]}
        eng=MaplEngine(data,Path(temp)/'fixture.pdf',pretendard_zip=font_zip,strict=False)
        cover=eng._make_cover()
        with fitz.open(stream=cover,filetype='pdf') as pdf:
            txt=pdf[0].get_text()
            assert '선형대수' in txt, txt
            assert 'ACTUARIAL' not in txt and 'STATISTICS' not in txt, txt
        eng.page('test','inline spacing')
        x,y=52,130
        left,right='왼쪽글자','오른쪽글자'
        size=9.0
        eng.rich(x,y,left+r'\(x+1\)'+right,width=320,size=size,leading=14)
        assert len(eng.math_placements)==1
        placement=eng.math_placements[0]
        left_end=x+pdfmetrics.stringWidth(left,eng.fonts['r'][0],size)
        left_gap=placement['rect'][0]-left_end
        expected=max(1.9,size*.24)
        assert abs(left_gap-expected)<.03,(left_gap,expected)
        eng.end();eng.c.save()
        with fitz.open(stream=eng.buf.getvalue(),filetype='pdf') as pdf:
            spans=[span for block in pdf[0].get_text('dict')['blocks'] for line in block.get('lines',[])
                   for span in line.get('spans',[]) if span.get('text','')==right]
            assert spans, 'Right-side Korean fragment not found'
            right_gap=spans[0]['bbox'][0]-placement['rect'][2]
            assert abs(right_gap-expected)<.06, (right_gap,expected)
            assert abs(left_gap-right_gap)<.07, (left_gap,right_gap)
        eng.latex.close()
        # Formula crosses a line boundary: left pad MUST be dropped.
        wrap=MaplEngine(data,Path(temp)/'wrap.pdf',pretendard_zip=font_zip,strict=False)
        wrap.page('test','wrap')
        word='가나다라마바사아자차카타파하'
        formula_w=wrap.latex.measure('x+1',scale=.9)[0]
        word_w=pdfmetrics.stringWidth(word,wrap.fonts['r'][0],size)
        constrained=word_w+expected+formula_w/2
        wrap.rich(50,95,word+r'\(x+1\)다음',constrained,size=size,leading=14)
        assert len(wrap.math_placements)==1
        assert abs(wrap.math_placements[0]['rect'][0]-50)<.03,wrap.math_placements
        wrap.latex.close()
    print('PASS: Subject-specific cover / symmetric inline spacing / clean wrapped formula')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--font-zip');args=p.parse_args()
    run(args.font_zip)
